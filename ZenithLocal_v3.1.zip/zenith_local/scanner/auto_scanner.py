"""Auto-scan scheduler — runs a full security scan on a configurable interval."""
import threading
import time
from datetime import datetime
from typing import Callable, Optional

class AutoScanner:
    """Runs a callback on a fixed interval (in minutes).
    Thread-safe, restartable, no external dependencies."""

    def __init__(self):
        self._lock      = threading.Lock()
        self._thread: Optional[threading.Thread] = None
        self._stop      = threading.Event()
        self._interval  = 0          # minutes; 0 = disabled
        self._callback: Optional[Callable] = None
        self._last_run: Optional[str] = None
        self._next_run: Optional[str] = None
        self._running   = False

    def configure(self, interval_minutes: int, callback: Callable):
        """Set interval (0 = disable) and the function to call each tick."""
        with self._lock:
            self._interval = interval_minutes
            self._callback  = callback
        self.restart()

    def restart(self):
        self.stop()
        with self._lock:
            if self._interval <= 0:
                self._next_run = None
                return
        self._stop.clear()
        t = threading.Thread(target=self._loop, daemon=True)
        with self._lock:
            self._thread = t
        t.start()

    def stop(self):
        self._stop.set()
        with self._lock:
            t = self._thread
        if t and t.is_alive():
            t.join(timeout=5)
        with self._lock:
            self._thread = None
            self._next_run = None

    def _loop(self):
        with self._lock:
            interval_s = self._interval * 60
        # Wait for the first interval before scanning
        next_at = time.time() + interval_s
        with self._lock:
            self._next_run = datetime.fromtimestamp(next_at).isoformat(timespec="seconds")

        while not self._stop.wait(timeout=1):
            if time.time() >= next_at:
                with self._lock:
                    cb = self._callback
                    self._running   = True
                    self._last_run  = datetime.now().isoformat(timespec="seconds")
                try:
                    if cb:
                        cb()
                except Exception:
                    pass
                finally:
                    with self._lock:
                        self._running = False
                next_at = time.time() + interval_s
                with self._lock:
                    self._next_run = datetime.fromtimestamp(next_at).isoformat(timespec="seconds")

    def status(self):
        with self._lock:
            return {
                "enabled":     self._interval > 0 and self._thread is not None,
                "interval_min": self._interval,
                "last_run":    self._last_run,
                "next_run":    self._next_run,
                "running_now": self._running,
            }


# Singleton instance used by app.py
_scanner = AutoScanner()

def get_scheduler():
    return _scanner
