"""Real-time file activity watcher for a small set of high-risk folders (Downloads,
Desktop, the Startup folder, plus anything the user adds). Uses watchdog, which on
Windows is backed by ReadDirectoryChangesW - event-driven, not polling, so it stays
cheap even though it's always running. Deliberately does NOT watch System32 by
default: it changes constantly during normal Windows operation (Windows Update,
services, etc.), so a naive watch there is mostly noise and needs Administrator
rights just to open the folder handle. Add it manually in Settings if you want it.
"""
import os
import threading
import time
from pathlib import Path
from collections import deque

from watchdog.events import FileSystemEventHandler
from watchdog.observers import Observer

MAX_EVENTS = 300
BURST_WINDOW_SECONDS = 20
BURST_THRESHOLD = 15  # this many file events inside the window = possible ransomware burst

_events = deque(maxlen=MAX_EVENTS)
_lock = threading.Lock()
_observer = None
_watched_paths = []
_alert_state = {"active": False, "since": None, "recent_count": 0}


class _Handler(FileSystemEventHandler):
    def __init__(self, watched_label):
        self.watched_label = watched_label

    def _record(self, event_type, path):
        # Capture useful metadata while keeping the watcher lightweight.
        raw_path = path
        src_path = path
        dest_path = None
        if event_type == "renamed" and " -> " in path:
            src_path, dest_path = path.split(" -> ", 1)
        probe = dest_path or src_path
        p = Path(probe)
        try:
            st = p.stat()
            size = st.st_size if p.is_file() else None
            exists = True
        except (OSError, ValueError):
            size = None
            exists = False
        suffix = p.suffix.lower() if p.suffix else ""
        item = {
            "time": time.time(), "type": event_type, "path": raw_path,
            "watched": self.watched_label, "name": p.name,
            "extension": suffix.lstrip(".") or "(none)",
            "directory": str(p.parent), "size": size, "exists": exists,
            "is_directory": False,
        }
        with _lock:
            _events.append(item)
            _check_burst_locked()

    def on_created(self, event):
        if not event.is_directory:
            self._record("created", event.src_path)

    def on_modified(self, event):
        if not event.is_directory:
            self._record("modified", event.src_path)

    def on_deleted(self, event):
        if not event.is_directory:
            self._record("deleted", event.src_path)

    def on_moved(self, event):
        if not event.is_directory:
            self._record("renamed", f"{event.src_path} -> {event.dest_path}")


def _check_burst_locked():
    """Caller must hold _lock. Flags a possible ransomware-style burst when many
    file events land in a short rolling window."""
    now = time.time()
    recent = [e for e in _events if now - e["time"] <= BURST_WINDOW_SECONDS]
    _alert_state["recent_count"] = len(recent)
    if len(recent) >= BURST_THRESHOLD:
        if not _alert_state["active"]:
            _alert_state["since"] = now
        _alert_state["active"] = True
    else:
        _alert_state["active"] = False
        _alert_state["since"] = None


def default_watch_paths():
    home = os.environ.get("USERPROFILE") or os.path.expanduser("~")
    candidates = [
        os.path.join(home, "Downloads"),
        os.path.join(home, "Desktop"),
        os.path.join(home, "AppData", "Roaming", "Microsoft", "Windows", "Start Menu", "Programs", "Startup"),
    ]
    return [p for p in candidates if os.path.isdir(p)]


def start(paths=None):
    """Idempotent: call restart() instead if the watcher is already running and you
    want to change what it watches."""
    global _observer, _watched_paths
    if _observer is not None:
        return
    paths = paths if paths else default_watch_paths()
    _watched_paths = []
    _observer = Observer()
    for p in paths:
        if not os.path.isdir(p):
            continue
        try:
            _observer.schedule(_Handler(p), p, recursive=True)
            _watched_paths.append(p)
        except OSError:
            continue
    if _watched_paths:
        _observer.daemon = True
        _observer.start()
    else:
        _observer = None


def stop():
    global _observer
    if _observer is not None:
        _observer.stop()
        _observer.join(timeout=5)
        _observer = None


def restart(paths):
    stop()
    with _lock:
        _events.clear()
        _alert_state.update({"active": False, "since": None, "recent_count": 0})
    start(paths)


def get_events(limit=100):
    with _lock:
        items = list(_events)[-limit:]
    return list(reversed(items))


def get_alert_state():
    with _lock:
        return dict(_alert_state)


def get_watched_paths():
    return list(_watched_paths)

def clear_events():
    with _lock:
        _events.clear()
        _alert_state.update({"active": False, "since": None, "recent_count": 0})
