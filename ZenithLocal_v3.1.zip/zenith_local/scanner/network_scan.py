"""Checks what the machine exposes on the network: listening ports and firewall state."""
import ipaddress

import psutil

from .risk_engine import finding
from .ps import run_ps_safe

# Ports that are risky to expose, especially on all interfaces (0.0.0.0) rather than localhost.
RISKY_PORTS = {
    21: ("FTP", "high", "Unencrypted file transfer; credentials and data travel in plain text.", None),
    23: ("Telnet", "critical", "Unencrypted remote shell; credentials travel in plain text.", None),
    135: ("RPC Endpoint Mapper", "medium", "Commonly targeted by lateral-movement and worm-style attacks.", None),
    139: ("NetBIOS", "medium", "Legacy file-sharing protocol, frequent target for exploitation.", None),
    445: ("SMB", "high", "File-sharing protocol behind major worms (WannaCry, NotPetya) when exposed externally.",
          "https://nvd.nist.gov/vuln/detail/CVE-2017-0144"),
    1433: ("SQL Server", "high", "Database port; exposure invites brute-force and injection attempts.", None),
    3306: ("MySQL", "high", "Database port; should not be reachable outside localhost/VPN.", None),
    3389: ("RDP", "critical", "Remote Desktop; a leading entry point for ransomware when exposed to the internet.",
           "https://nvd.nist.gov/vuln/detail/CVE-2019-0708"),
    5900: ("VNC", "critical", "Remote desktop protocol, frequently deployed with weak or no authentication.", None),
}


def _process_name(pid):
    if not pid:
        return "unknown"
    try:
        return psutil.Process(pid).name()
    except (psutil.NoSuchProcess, psutil.AccessDenied):
        return "unknown"


def scan_listening_ports():
    findings = []
    listening = []
    try:
        conns = psutil.net_connections(kind="inet")
    except (psutil.AccessDenied, PermissionError):
        return [finding(
            "network", "info", "Could not enumerate network connections",
            "Reading the full connection table needs administrator rights.",
            "Re-run this tool as Administrator for a complete port scan.",
        )], []

    for c in conns:
        if c.status != psutil.CONN_LISTEN or not c.laddr:
            continue
        port = c.laddr.port
        addr = c.laddr.ip
        proc = _process_name(c.pid)
        listening.append({"port": port, "address": addr, "process": proc, "pid": c.pid})

        exposed = addr in ("0.0.0.0", "::")
        if port in RISKY_PORTS:
            label, sev, why, ref = RISKY_PORTS[port]
            if not exposed:
                sev = "low" if sev != "critical" else "medium"
            findings.append(finding(
                "network", sev,
                f"Port {port} ({label}) is listening" + (" on all interfaces" if exposed else " on localhost only"),
                f"{why} Process: {proc} (pid {c.pid}).",
                "Close this port if it isn't needed, bind it to localhost only, or restrict access with the firewall."
                if exposed else "Low risk since it's bound to localhost, but confirm the service is expected.",
                evidence=[f"{addr}:{port} -> {proc}"],
                reference=ref,
            ))

    return findings, listening


def scan_firewall():
    data, err = run_ps_safe(
        "Get-NetFirewallProfile | Select-Object Name,Enabled | ConvertTo-Json"
    )
    if err or data is None:
        return [finding(
            "network", "medium", "Could not read Windows Firewall status",
            err or "No data returned.",
            "Open Windows Security > Firewall & network protection and confirm all profiles are On.",
        )]

    profiles = data if isinstance(data, list) else [data]
    findings = []
    for p in profiles:
        if not p.get("Enabled", True):
            findings.append(finding(
                "network", "critical",
                f"Windows Firewall is OFF for the {p.get('Name', 'unknown')} profile",
                "With the firewall disabled, any listening service is reachable without filtering.",
                f"Enable the firewall: Set-NetFirewallProfile -Name {p.get('Name', 'Domain')} -Enabled True",
            ))
    return findings


def run():
    port_findings, listening = scan_listening_ports()
    firewall_findings = scan_firewall()
    return port_findings + firewall_findings, {"listening_ports": listening}


def is_private_or_local(ip):
    try:
        addr = ipaddress.ip_address(ip)
        return addr.is_private or addr.is_loopback or addr.is_link_local
    except ValueError:
        return False


def get_active_connections(limit=150):
    """Outbound/established connections with the owning process - answers "what is
    talking to the internet right now", like a lightweight per-process netstat."""
    try:
        conns = psutil.net_connections(kind="inet")
    except (psutil.AccessDenied, PermissionError):
        return [], "Reading connections needs Administrator rights"

    results = []
    for c in conns:
        if c.status == psutil.CONN_LISTEN or not c.raddr:
            continue
        proc = _process_name(c.pid)
        remote_ip = c.raddr.ip
        results.append({
            "local": f"{c.laddr.ip}:{c.laddr.port}" if c.laddr else "",
            "remote": f"{remote_ip}:{c.raddr.port}",
            "remote_ip": remote_ip,
            "status": c.status,
            "pid": c.pid,
            "process": proc,
            "foreign": not is_private_or_local(remote_ip),
        })
        if len(results) >= limit:
            break
    return results, None
