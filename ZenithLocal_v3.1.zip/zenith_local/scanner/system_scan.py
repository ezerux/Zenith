"""Checks core Windows security settings that are common attack surface."""
from .risk_engine import finding
from .ps import run_ps_safe


def check_uac():
    data, err = run_ps_safe(
        "Get-ItemProperty 'HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System' "
        "| Select-Object EnableLUA | ConvertTo-Json"
    )
    if err or data is None:
        return [finding("system", "info", "Could not read UAC setting", err or "No data.",
                         "Check manually: Control Panel > User Accounts > Change User Account Control settings.")]
    if data.get("EnableLUA") == 0:
        return [finding(
            "system", "high", "User Account Control (UAC) is disabled",
            "Malware and scripts can gain admin privileges silently, without a consent prompt.",
            "Re-enable UAC: Control Panel > User Accounts > Change User Account Control settings.",
            reference="https://learn.microsoft.com/windows/security/application-security/application-control/user-account-control",
        )]
    return []


def check_rdp():
    data, err = run_ps_safe(
        "Get-ItemProperty 'HKLM:\\SYSTEM\\CurrentControlSet\\Control\\Terminal Server' "
        "| Select-Object fDenyTSConnections | ConvertTo-Json"
    )
    if err or data is None:
        return [finding("system", "info", "Could not read Remote Desktop setting", err or "No data.", "Check System > Remote Desktop settings manually.")]
    if data.get("fDenyTSConnections") == 0:
        return [finding(
            "system", "medium", "Remote Desktop (RDP) is enabled",
            "RDP is a leading ransomware entry point if reachable from the internet or a weak password is used. "
            "The BlueKeep vulnerability (CVE-2019-0708) allowed unauthenticated remote code execution over RDP.",
            "Disable RDP if unused, or restrict it to a VPN and enforce Network Level Authentication + strong passwords.",
            reference="https://nvd.nist.gov/vuln/detail/CVE-2019-0708",
        )]
    return []


def check_smb1():
    data, err = run_ps_safe(
        "Get-WindowsOptionalFeature -Online -FeatureName SMB1Protocol | Select-Object State | ConvertTo-Json"
    )
    if err or data is None:
        return []
    if data.get("State") == "Enabled":
        return [finding(
            "system", "critical", "Legacy SMBv1 protocol is enabled",
            "SMBv1 has a critical remote code execution flaw (CVE-2017-0144, \"EternalBlue\") exploited by "
            "WannaCry and NotPetya to spread automatically across networks with no user interaction required.",
            "Disable it: Disable-WindowsOptionalFeature -Online -FeatureName SMB1Protocol",
            reference="https://nvd.nist.gov/vuln/detail/CVE-2017-0144",
        )]
    return []


def check_windows_update():
    data, err = run_ps_safe(
        "Get-HotFix | Sort-Object InstalledOn -Descending | Select-Object -First 1 InstalledOn | ConvertTo-Json"
    )
    if err or not data:
        return [finding(
            "system", "info", "Could not determine last Windows Update install date", err or "No hotfix history found.",
            "Open Settings > Windows Update and check for updates manually.",
        )]
    from datetime import datetime
    raw = data.get("InstalledOn")
    if not raw:
        return []
    try:
        # PowerShell JSON dates come back as /Date(1690000000000)/ 
        if isinstance(raw, str) and raw.startswith("/Date("):
            ms = int(raw.replace("/Date(", "").replace(")/", "").split("+")[0])
            installed = datetime.fromtimestamp(ms / 1000)
        else:
            installed = datetime.fromisoformat(str(raw))
    except (ValueError, TypeError):
        return []
    days_old = (datetime.now() - installed).days
    if days_old > 60:
        return [finding(
            "system", "high", "Windows has not been updated in a long time",
            f"Last installed update was {days_old} days ago ({installed.date()}).",
            "Open Settings > Windows Update > Check for updates and install pending updates.",
        )]
    if days_old > 30:
        return [finding(
            "system", "medium", "Windows updates are somewhat overdue",
            f"Last installed update was {days_old} days ago ({installed.date()}).",
            "Check for updates in Settings > Windows Update.",
        )]
    return []


def check_guest_account():
    data, err = run_ps_safe(
        "Get-LocalUser -Name Guest | Select-Object Enabled | ConvertTo-Json"
    )
    if err or data is None:
        return []
    if data.get("Enabled"):
        return [finding(
            "system", "high", "The built-in Guest account is enabled",
            "An enabled Guest account can allow anonymous or low-friction access to the machine.",
            "Disable it: Disable-LocalUser -Name Guest",
        )]
    return []


def check_local_admins():
    data, err = run_ps_safe(
        "Get-LocalGroupMember -Group 'Administrators' | Select-Object Name,ObjectClass | ConvertTo-Json"
    )
    if err or data is None:
        return [], []
    members = data if isinstance(data, list) else [data]
    names = [m.get("Name", "unknown") for m in members]
    findings = []
    if len(names) > 3:
        findings.append(finding(
            "system", "medium", f"{len(names)} accounts have local administrator rights",
            "Every admin account is a potential path to full system compromise if its credentials leak.",
            "Review this list and remove admin rights from any account that doesn't need them: " + ", ".join(names),
            evidence=names,
        ))
    return findings, names


def check_startup_items():
    data, err = run_ps_safe(
        "Get-CimInstance Win32_StartupCommand | Select-Object Name,Command,Location | ConvertTo-Json"
    )
    if err or data is None:
        return [], []
    items = data if isinstance(data, list) else [data]
    parsed = [{"name": i.get("Name"), "command": i.get("Command"), "location": i.get("Location")} for i in items]
    f = []
    if len(parsed) > 15:
        f.append(finding(
            "system", "low", f"{len(parsed)} programs launch automatically at startup",
            "A large number of auto-start entries increases attack surface and startup time.",
            "Review the Startup list and disable anything unrecognized (Task Manager > Startup apps).",
        ))
    return f, parsed


def run():
    findings = []
    findings += check_uac()
    findings += check_rdp()
    findings += check_smb1()
    findings += check_windows_update()
    findings += check_guest_account()
    admin_findings, admins = check_local_admins()
    findings += admin_findings
    startup_findings, startup_items = check_startup_items()
    findings += startup_findings
    return findings, {"local_admins": admins, "startup_items": startup_items}
