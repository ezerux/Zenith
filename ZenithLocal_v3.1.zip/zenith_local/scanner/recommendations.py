"""Security recommendations engine.
Analyzes findings and system state to produce prioritized, actionable advice."""
from datetime import datetime

# ── Rule definitions ─────────────────────────────────────────────────────────
# Each rule: (id, priority, title, detail, fix_command_or_steps)
RULES = [
    # Firewall
    ("fw_off",      "critical",
     "Windows Firewall is disabled on at least one profile",
     "A disabled firewall exposes all listening services to the network without filtering.",
     "Set-NetFirewallProfile -All -Enabled True"),

    # SMBv1
    ("smb1_on",     "critical",
     "Legacy SMBv1 protocol is enabled",
     "SMBv1 was exploited by WannaCry and NotPetya. There is no reason to keep it enabled.",
     "Disable-WindowsOptionalFeature -Online -FeatureName SMB1Protocol -NoRestart"),

    # RDP open to internet
    ("rdp_exposed", "critical",
     "RDP is enabled and port 3389 is open on all interfaces",
     "Remote Desktop exposed to all interfaces is the #1 ransomware entry point.",
     "Disable RDP if unused: System Properties → Remote → Disable Remote Desktop. "
     "Or restrict via firewall to your VPN IP only."),

    # UAC
    ("uac_off",     "high",
     "User Account Control (UAC) is disabled",
     "Without UAC, any process can silently escalate to Administrator.",
     "reg add HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System /v EnableLUA /t REG_DWORD /d 1 /f"),

    # Defender real-time
    ("av_rt_off",   "critical",
     "Real-time antivirus protection is disabled",
     "Files are not scanned as they are created or executed. Malware can run freely.",
     "Enable in Windows Security → Virus & threat protection → Manage settings."),

    # Outdated signatures
    ("av_old_sig",  "high",
     "Antivirus signatures are more than 7 days old",
     "Outdated signatures miss recent malware families.",
     "Open Windows Security → Virus & threat protection → Check for updates."),

    # Guest account
    ("guest_on",    "high",
     "Built-in Guest account is enabled",
     "An enabled Guest account provides low-friction anonymous access.",
     "Disable-LocalUser -Name Guest"),

    # Old drivers
    ("old_drivers", "medium",
     "Several drivers have not been updated in over 2 years",
     "Outdated drivers can contain known vulnerabilities and cause instability.",
     "Check the Drivers tab for download links for each outdated driver."),

    # No recent scan
    ("no_scan",     "medium",
     "No malware scan has been run in the last 14 days",
     "Regular scans are the baseline of endpoint security.",
     "Go to Malware / AV and run at least a Quick Scan."),

    # Many admins
    ("many_admins", "medium",
     "More than 2 accounts have local Administrator rights",
     "Every admin account is a potential path to full system compromise.",
     "Run: Get-LocalGroupMember -Group Administrators — remove unnecessary accounts."),

    # Autorun suspicious
    ("autorun_sus", "high",
     "Suspicious entries found in Registry autoruns",
     "Malware commonly hides in Run/RunOnce registry keys.",
     "Review and remove suspicious entries in the Registry tab."),

    # Outdated OS
    ("os_old",      "medium",
     "Windows has not been updated in more than 60 days",
     "Unpatched Windows can be exploited via known CVEs.",
     "Settings → Windows Update → Check for updates."),

    # Open suspicious port
    ("susp_port",   "high",
     "A known-risky port is open on all network interfaces",
     "Ports such as 23 (Telnet), 5900 (VNC), 445 (SMB) should not be exposed externally.",
     "Close the port or restrict it to localhost using the Firewall tab."),
]

RULE_MAP = {r[0]: r for r in RULES}


def _finding_titles(findings):
    return " ".join(f.get("title","").lower() for f in findings)


def _has(findings, *keywords):
    text = _finding_titles(findings)
    return any(kw.lower() in text for kw in keywords)


def generate(findings, scan_meta=None, driver_data=None):
    """
    Analyze findings + optional context and return a list of recommendations.
    Each recommendation: {id, priority, title, detail, fix, triggered_by}
    """
    recs  = []
    added = set()

    def add(rule_id, triggered_by=""):
        if rule_id in added:
            return
        r = RULE_MAP.get(rule_id)
        if r:
            recs.append({
                "id":           r[0],
                "priority":     r[1],
                "title":        r[2],
                "detail":       r[3],
                "fix":          r[4],
                "triggered_by": triggered_by,
            })
            added.add(rule_id)

    # ── Check findings ─────────────────────────────────
    for f in findings:
        t   = f.get("title", "").lower()
        sev = f.get("severity", "")

        if "firewall" in t and ("off" in t or "disabled" in t):
            add("fw_off", f["title"])
        if "smb" in t and "1" in t:
            add("smb1_on", f["title"])
        if "rdp" in t and ("enabled" in t or "listening" in t):
            if "all interface" in t or sev in ("critical","high"):
                add("rdp_exposed", f["title"])
        if "uac" in t and "disabled" in t:
            add("uac_off", f["title"])
        if "real-time" in t and "disabled" in t:
            add("av_rt_off", f["title"])
        if "signature" in t and ("outdated" in t or "old" in t):
            add("av_old_sig", f["title"])
        if "guest" in t and "enabled" in t:
            add("guest_on", f["title"])
        if "administrator" in t and ("accounts" in t or "rights" in t):
            add("many_admins", f["title"])
        if "autorun" in t or ("registry" in t and "suspicious" in t):
            add("autorun_sus", f["title"])
        if "windows has not been updated" in t or "updates" in t and "overdue" in t:
            add("os_old", f["title"])
        if ("port" in t or "listening" in t) and sev in ("critical","high"):
            add("susp_port", f["title"])
        if "scan" in t and "not been run" in t:
            add("no_scan", f["title"])

    # ── Check scan age ─────────────────────────────────
    if scan_meta and scan_meta.get("ran_at"):
        try:
            ran = datetime.fromisoformat(scan_meta["ran_at"])
            if (datetime.now() - ran).days > 14:
                add("no_scan", "Last scan was more than 14 days ago")
        except ValueError:
            pass

    # ── Check drivers ──────────────────────────────────
    if driver_data:
        old = [d for d in driver_data if (d.get("age_days") or 0) > 365*2]
        if len(old) >= 3:
            add("old_drivers", f"{len(old)} outdated drivers found")

    # ── Sort by priority ──────────────────────────────
    order = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}
    recs.sort(key=lambda r: order.get(r["priority"], 9))

    return recs
