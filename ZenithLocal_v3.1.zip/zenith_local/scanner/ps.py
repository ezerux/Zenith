"""Helpers for invoking PowerShell from Python and getting structured data back."""
import json
import platform
import subprocess

# Prevent PowerShell / console window from popping up on Windows
SUBPROCESS_FLAGS = {}
if platform.system() == "Windows":
    # CREATE_NO_WINDOW prevents Windows from creating a new console window
    SUBPROCESS_FLAGS["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)
    # STARTUPINFO SW_HIDE ensures the process window stays hidden
    si = subprocess.STARTUPINFO()
    si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    si.wShowWindow = 0  # SW_HIDE
    SUBPROCESS_FLAGS["startupinfo"] = si


class PowerShellError(Exception):
    pass


def run_ps(command, timeout=60):
    """Run a PowerShell command and return raw stdout text. Raises PowerShellError on failure."""
    try:
        result = subprocess.run(
            [
                "powershell",
                "-WindowStyle", "Hidden",
                "-NoProfile",
                "-NonInteractive",
                "-ExecutionPolicy", "Bypass",
                "-Command", command,
            ],
            capture_output=True,
            text=True,
            timeout=timeout,
            **SUBPROCESS_FLAGS,
        )
    except FileNotFoundError as exc:
        raise PowerShellError("PowerShell not found on this system.") from exc
    except subprocess.TimeoutExpired as exc:
        raise PowerShellError(f"PowerShell command timed out after {timeout}s.") from exc

    if result.returncode != 0 and not result.stdout.strip():
        raise PowerShellError(result.stderr.strip() or "PowerShell command failed with no output.")

    return result.stdout.strip()


def run_ps_json(command, timeout=60):
    """Run a PowerShell command whose output ends with ConvertTo-Json and parse it.
    Returns [] / {} gracefully if there's no output. Always wrap the piped objects
    with @() in the caller so a single result still comes back as a JSON array."""
    raw = run_ps(command, timeout=timeout)
    if not raw:
        return None
    try:
        return json.loads(raw)
    except json.JSONDecodeError as exc:
        raise PowerShellError(f"Could not parse PowerShell JSON output: {exc}\nRaw: {raw[:500]}") from exc


def run_ps_safe(command, timeout=60, default=None):
    """Like run_ps_json but never raises - returns `default` and an error string instead."""
    try:
        return run_ps_json(command, timeout=timeout), None
    except PowerShellError as exc:
        return default, str(exc)
