"""Windows Services Manager — list, start, stop, restart services via PowerShell."""
from .ps import run_ps_safe, run_ps

SERVICE_RISK = {
    "RemoteRegistry": ("high", "Allows remote registry access — commonly exploited."),
    "TlntSvr":        ("critical", "Telnet server — unencrypted, should never run."),
    "WinRM":          ("medium", "Windows Remote Management — disable if not needed."),
    "TermService":    ("medium", "Remote Desktop — disable if not needed."),
    "SharedAccess":   ("low",    "Internet Connection Sharing."),
    "SNMP":           ("medium", "SNMP — exposes system info to network."),
    "Fax":            ("low",    "Fax service — rarely needed."),
    "XblGameSave":    ("info",   "Xbox game save — disable on non-gaming machines."),
}

def list_services(filter_text="", status_filter="all"):
    """Return list of services with status, start type and risk info."""
    cmd = (
        "Get-Service | Select-Object Name,DisplayName,Status,StartType | "
        "ConvertTo-Json -Depth 2"
    )
    data, err = run_ps_safe(cmd, timeout=30)
    if err or not data:
        return [], err or "Could not enumerate services."

    services = data if isinstance(data, list) else [data]
    result = []
    for s in services:
        name    = s.get("Name", "")
        display = s.get("DisplayName", "")
        status  = str(s.get("Status", ""))
        start   = str(s.get("StartType", ""))
        risk, risk_desc = SERVICE_RISK.get(name, (None, None))

        if filter_text and filter_text.lower() not in name.lower() and filter_text.lower() not in display.lower():
            continue
        if status_filter != "all" and status.lower() != status_filter.lower():
            continue

        result.append({
            "name":      name,
            "display":   display,
            "status":    status,
            "start_type": start,
            "risk":      risk,
            "risk_desc": risk_desc,
        })

    result.sort(key=lambda x: (0 if x["risk"] in ("critical","high") else 1, x["display"].lower()))
    return result, None


def control_service(name, action):
    """Start, stop, or restart a service. action: 'start'|'stop'|'restart'."""
    safe_name = name.replace('"', '').replace("'", "").replace(";", "").strip()
    if not safe_name:
        return False, "Invalid service name."

    if action == "start":
        cmd = f"Start-Service -Name '{safe_name}' -ErrorAction Stop"
    elif action == "stop":
        cmd = f"Stop-Service -Name '{safe_name}' -Force -ErrorAction Stop"
    elif action == "restart":
        cmd = f"Restart-Service -Name '{safe_name}' -Force -ErrorAction Stop"
    else:
        return False, f"Unknown action: {action}"

    try:
        run_ps(cmd, timeout=30)
        return True, None
    except Exception as exc:
        return False, str(exc)


def set_start_type(name, start_type):
    """Set service start type: Automatic, Manual, Disabled."""
    safe = name.replace('"','').replace("'","").replace(";","").strip()
    valid = {"Automatic", "Manual", "Disabled"}
    if start_type not in valid:
        return False, f"Invalid start type. Must be one of: {valid}"
    try:
        run_ps(f"Set-Service -Name '{safe}' -StartupType {start_type} -ErrorAction Stop", timeout=20)
        return True, None
    except Exception as exc:
        return False, str(exc)
