"""Driver update scanner: lists installed drivers via WMI/PnP,
flags those whose DriverDate is old, and provides manufacturer
download links based on device class + vendor."""
import re
from datetime import datetime
from .ps import run_ps_safe
from .risk_engine import finding

OLD_DRIVER_DAYS = 365 * 2   # older than 2 years = flag

# Download portals keyed by manufacturer name fragment (lowercase)
VENDOR_URLS = {
    "nvidia":   "https://www.nvidia.com/en-us/drivers/",
    "amd":      "https://www.amd.com/en/support",
    "advanced micro":  "https://www.amd.com/en/support",
    "intel":    "https://www.intel.com/content/www/us/en/support/detect.html",
    "realtek":  "https://www.realtek.com/en/downloads",
    "qualcomm": "https://www.qualcomm.com/support",
    "broadcom": "https://www.broadcom.com/support/download-search",
    "marvell":  "https://www.marvell.com/support/downloads.html",
    "tp-link":  "https://www.tp-link.com/en/support/download/",
    "microsoft":"https://www.catalog.update.microsoft.com/",
}

CLASS_PRIORITY = {
    "Display":       "high",
    "Net":           "medium",
    "Media":         "low",
    "HDC":           "medium",
    "DiskDrive":     "medium",
    "AudioEndpoint": "low",
    "System":        "info",
    "USB":           "low",
    "Bluetooth":     "low",
}

def _vendor_url(mfr):
    if not mfr: return None
    mfr_l = mfr.lower()
    for key, url in VENDOR_URLS.items():
        if key in mfr_l:
            return url
    return None

def _parse_wmi_date(s):
    """WMI dates come back as '20210901000000.000000-000' or ISO."""
    if not s:
        return None
    s = str(s)
    if "Date(" in s:
        try:
            ms = int(re.search(r"\d+", s).group())
            return datetime.fromtimestamp(ms / 1000)
        except Exception:
            return None
    if len(s) >= 8 and s[:8].isdigit():
        try: return datetime.strptime(s[:8], "%Y%m%d")
        except: pass
    for fmt in ("%Y-%m-%dT%H:%M:%S", "%Y-%m-%d"):
        try: return datetime.strptime(s[:10], fmt)
        except: pass
    return None

def scan_drivers():
    data, err = run_ps_safe(
        "Get-WmiObject Win32_PnPSignedDriver | Where-Object {$_.DeviceName -ne $null} | "
        "Select-Object DeviceName,DriverVersion,DriverDate,Manufacturer,DeviceClass,InfName,DeviceID | "
        "ConvertTo-Json -Depth 3",
        timeout=45)
    if err or not data:
        return [finding(
            "drivers", "info", "Could not enumerate drivers",
            err or "No driver data returned. Administrator rights may be needed.",
            "Re-run as Administrator for full driver information.",
        )], []

    drivers = data if isinstance(data, list) else [data]

    # Hardware IDs are the identifiers Windows uses to match a device to a driver.
    # Prefer the most specific ID exposed by the PnP device; fall back to DeviceID.
    hw_script = r"$ErrorActionPreference='SilentlyContinue'; $out=@(); Get-PnpDevice -PresentOnly | ForEach-Object { $ids=@(); try { $x=(Get-PnpDeviceProperty -InstanceId $_.InstanceId -KeyName 'DEVPKEY_Device_HardwareIds').Data; if($x){$ids=@($x)} } catch {}; $out += [pscustomobject]@{InstanceId=$_.InstanceId;HardwareIds=$ids} }; $out | ConvertTo-Json -Depth 5"
    hw_data, _ = run_ps_safe(hw_script, timeout=60)
    hw_items = hw_data if isinstance(hw_data, list) else ([hw_data] if hw_data else [])
    hw_map = {str(x.get("InstanceId") or "").lower(): list(x.get("HardwareIds") or []) for x in hw_items if isinstance(x, dict)}

    now = datetime.now()
    findings = []
    results  = []
    for d in drivers:
        name  = d.get("DeviceName") or ""
        ver   = d.get("DriverVersion") or ""
        mfr   = d.get("Manufacturer") or ""
        cls   = d.get("DeviceClass") or ""
        date_raw = d.get("DriverDate")
        date = _parse_wmi_date(date_raw)
        age_days = (now - date).days if date else None
        url  = _vendor_url(mfr)
        device_id = str(d.get("DeviceID") or "")
        ids = hw_map.get(device_id.lower(), [])
        if isinstance(ids, str): ids = [ids]
        if not ids and device_id: ids = [device_id]
        entry = {
            "name": name, "version": ver, "manufacturer": mfr,
            "device_class": cls, "driver_date": str(date.date()) if date else None,
            "age_days": age_days, "download_url": url,
            "hardware_id": ids[0] if ids else None,
            "hardware_ids": ids,
            "device_id": device_id,
            "inf_name": d.get("InfName") or "",
        }
        results.append(entry)
        if age_days and age_days > OLD_DRIVER_DAYS:
            sev = CLASS_PRIORITY.get(cls, "low")
            findings.append(finding(
                "drivers", sev,
                f"Outdated driver: {name}",
                f"Driver version {ver} dated {entry['driver_date']} ({age_days} days old). "
                f"Manufacturer: {mfr}.",
                f"Download updated driver from the manufacturer." + (f" ↗ {url}" if url else ""),
                evidence=[ver],
                reference=url,
            ))
    # sort: most outdated first
    results.sort(key=lambda x: x.get("age_days") or 0, reverse=True)
    return findings, results

def run():
    f, drivers = scan_drivers()
    return f, {"drivers": drivers}
