@echo off
cd /d "%~dp0"
echo This window will NOT close by itself. Read whatever appears below,
echo then copy all of it and send it back.
echo ============================================
echo.
cmd /k start.bat
