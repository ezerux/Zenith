"""
Hskich - Desktop Application Runner.
Opens the Hskich Security Dashboard inside a native desktop software window
instead of a web browser, keeping the exact same UI, styles, and full functionality.
"""
import ctypes
import os
import platform
import socket
import subprocess
import sys
import threading
import time

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)

from app import app, config_store, file_watch, is_admin

DEFAULT_PORT = 5000
HOST = "127.0.0.1"


def find_available_port(start_port: int = DEFAULT_PORT) -> int:
    """Finds an available local port starting from start_port."""
    port = start_port
    while port < start_port + 50:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            if s.connect_ex((HOST, port)) != 0:
                return port
        port += 1
    return start_port


def is_server_ready(port: int, timeout: float = 10.0) -> bool:
    """Polls the local server until it responds or times out."""
    start_time = time.time()
    while time.time() - start_time < timeout:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(0.4)
            if s.connect_ex((HOST, port)) == 0:
                return True
        time.sleep(0.12)
    return False


def run_flask(port: int):
    """Runs the Flask web service in background."""
    import logging
    log = logging.getLogger("werkzeug")
    log.setLevel(logging.ERROR)

    try:
        file_watch.start(config_store.get_watch_paths())
    except Exception as exc:
        print(f"[Desktop] File watcher warning: {exc}", file=sys.stderr)

    app.run(host=HOST, port=port, debug=False, use_reloader=False)


def launch_standalone_app_mode(url: str):
    """
    Fallback if pywebview is not installed:
    Opens Edge or Chrome in standalone Desktop Application mode (--app=URL).
    This displays as an independent desktop software window with no URL bar,
    no browser tabs, and its own taskbar presence.
    """
    system = platform.system()
    candidates = []

    if system == "Windows":
        prog_files = os.environ.get("ProgramFiles", "C:\\Program Files")
        prog_files_x86 = os.environ.get("ProgramFiles(x86)", "C:\\Program Files (x86)")
        local_app_data = os.environ.get("LocalAppData", "")

        candidates = [
            os.path.join(prog_files_x86, "Microsoft", "Edge", "Application", "msedge.exe"),
            os.path.join(prog_files, "Microsoft", "Edge", "Application", "msedge.exe"),
            os.path.join(prog_files, "Google", "Chrome", "Application", "chrome.exe"),
            os.path.join(prog_files_x86, "Google", "Chrome", "Application", "chrome.exe"),
            os.path.join(local_app_data, "Google", "Chrome", "Application", "chrome.exe"),
            "msedge.exe",
            "msedge",
            "chrome.exe",
            "chrome",
        ]
    elif system == "Linux":
        candidates = [
            "google-chrome",
            "google-chrome-stable",
            "chromium",
            "chromium-browser",
            "microsoft-edge",
            "brave-browser",
        ]
    elif system == "Darwin":
        candidates = [
            "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
            "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
            "/Applications/Brave Browser.app/Contents/MacOS/Brave Browser",
        ]

    for binary in candidates:
        try:
            cmd = [binary, f"--app={url}", "--window-size=1280,850"]
            proc = subprocess.Popen(cmd)
            proc.wait()
            return True
        except FileNotFoundError:
            continue
        except Exception:
            continue

    # Final fallback: default system browser
    import webbrowser
    webbrowser.open(url)
    return False


def main():
    admin = is_admin()
    status_tag = " [Administrator]" if admin else ""
    title = f"Hskich · Local Security Watch{status_tag}"

    port = find_available_port(DEFAULT_PORT)
    url = f"http://{HOST}:{port}"

    # Start Flask in background daemon thread
    server_thread = threading.Thread(target=run_flask, args=(port,), daemon=True)
    server_thread.start()

    if not is_server_ready(port):
        print(f"[Desktop Error] Failed to start local server on {url}", file=sys.stderr)
        sys.exit(1)

    print(f"[Desktop] Server ready at {url}")

    # Option 1: Native window via PyWebView
    try:
        import webview
        window = webview.create_window(
            title=title,
            url=url,
            width=1280,
            height=850,
            min_size=(960, 600),
            text_select=True,
            zoomable=True,
            confirm_close=False,
        )
        webview.start()
        # Clean exit when desktop window is closed
        sys.exit(0)
    except ImportError:
        print("[Desktop] 'pywebview' is not installed.")
        print("[Desktop] Launching in Standalone Desktop App mode (Edge/Chrome)...")
        print("[Desktop] Tip: Run 'pip install pywebview' for a fully integrated native window.")
        launch_standalone_app_mode(url)
        sys.exit(0)
    except Exception as exc:
        print(f"[Desktop] PyWebView launch notice: {exc}", file=sys.stderr)
        print("[Desktop] Falling back to Standalone Desktop App mode...")
        launch_standalone_app_mode(url)
        sys.exit(0)


if __name__ == "__main__":
    main()
