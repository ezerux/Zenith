@echo off
setlocal enabledelayedexpansion
title Zenith Local - Local Security Watch (Desktop App)
cd /d "%~dp0"

echo ============================================
echo   Zenith Local - Local Security Watch (Desktop)
echo ============================================
echo.

set PY_CMD=
where py >nul 2>&1
if errorlevel 1 goto try_python
set PY_CMD=py -3
goto have_python

:try_python
where python >nul 2>&1
if errorlevel 1 goto no_python
set PY_CMD=python

:have_python
if "%PY_CMD%"=="" goto no_python

:check_venv
if exist "venv\Scripts\python.exe" goto venv_ready
echo [1/3] First run: creating local Python environment...
%PY_CMD% -m venv venv
if errorlevel 1 goto venv_failed
goto venv_ready

:no_python
echo [ERROR] No working Python installation was found.
echo Install Python 3.10+ from https://www.python.org/downloads/
echo Make sure to check "Add python.exe to PATH" during installation.
pause
exit /b 1

:venv_failed
echo [ERROR] Could not create virtual environment.
pause
exit /b 1

:venv_ready
set VENV_PY=venv\Scripts\python.exe
set VENV_PYW=venv\Scripts\pythonw.exe

echo [2/3] Verifying dependencies (Flask, pywebview, psutil, watchdog)...
"%VENV_PY%" -m pip install --quiet --upgrade pip
"%VENV_PY%" -m pip install --quiet -r requirements.txt
if errorlevel 1 (
    echo [WARNING] Some dependencies failed to install. Continuing with available packages...
)

echo [3/3] Launching Zenith Local Desktop Application...
echo NOTE: For complete scan results, run as Administrator.
echo.

REM Prefer pythonw.exe if available so no background CMD window stays open
if exist "%VENV_PYW%" (
    start "" "%VENV_PYW%" desktop.py
    exit /b 0
)

"%VENV_PY%" desktop.py
if errorlevel 1 (
    echo.
    echo [ERROR] Desktop app exited with an error.
    pause
    exit /b 1
)
exit /b 0
