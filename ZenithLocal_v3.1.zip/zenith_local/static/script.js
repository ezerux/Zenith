'use strict';

// ═══════════════════════════════════════════════════
// TOAST NOTIFICATIONS
// ═══════════════════════════════════════════════════
function toast(msg, type='success'){
  const t=document.createElement('div');
  t.className='toast toast-'+type;
  t.textContent=msg;
  document.body.appendChild(t);
  requestAnimationFrame(()=>t.classList.add('toast-show'));
  setTimeout(()=>{t.classList.remove('toast-show');setTimeout(()=>t.remove(),300);},2200);
}

// ═══════════════════════════════════════════════════
// NAV
// ═══════════════════════════════════════════════════
let monitorTimer=null, processSort='cpu', lastFindings=[], lastScanMeta=null, allLogEntries=[], allDrivers=[], allConns=[];

function switchView(id, push=true){
  document.querySelectorAll('.nav-item').forEach(n=>n.classList.toggle('active',n.dataset.view===id));
  document.querySelectorAll('.view').forEach(v=>v.classList.toggle('hidden',v.id!==`view-${id}`));
  if(id==='logs') loadLogs();
  if(id==='malware'){ loadClamavStatus(); loadDefenderStatus(); loadDbStats(); }
  if(id==='monitor') startMonitor(); else stopMonitor();
  if(id==='filewatch') loadWatchEvents();
  if(id==='network'){ loadPorts(); loadConnections(); }
  if(id==='registry') scanRegistry();
  if(id==='hardware') loadDisks();
  if(id==='drivers') loadDrivers();
  if(id==='sysinfo') loadSysInfo();
  if(push){ const u=new URL(location); u.searchParams.set('view',id); history.replaceState({},'',u); }
}

document.querySelectorAll('.nav-item').forEach(ni=>{
  ni.querySelector('.nav-label').addEventListener('click',()=>switchView(ni.dataset.view));
  ni.querySelector('.nav-popout')?.addEventListener('click',e=>{
    e.stopPropagation();
    const u=new URL(location.origin+location.pathname);
    u.searchParams.set('view',ni.dataset.view); window.open(u,'_blank');
  });
});

// TAB BARS
document.querySelectorAll('.tab-bar').forEach(bar=>{
  bar.querySelectorAll('.tab-btn').forEach(btn=>{
    btn.addEventListener('click',()=>{
      const p=btn.closest('.view');
      p.querySelectorAll('.tab-btn').forEach(b=>b.classList.remove('active'));
      p.querySelectorAll('.tab-pane').forEach(t=>t.classList.remove('active'));
      btn.classList.add('active');
      document.getElementById(`tab-${btn.dataset.tab}`)?.classList.add('active');
    });
  });
});

// ═══════════════════════════════════════════════════
// HELPERS
// ═══════════════════════════════════════════════════
const SEV={critical:'Critical',high:'High',medium:'Medium',low:'Low',info:'Info'};
const CAT={network:'Network',system:'System',malware:'Malware',logs:'Logs',hardware:'Hardware',drivers:'Drivers'};
function esc(s){const d=document.createElement('div');d.textContent=s??'';return d.innerHTML;}
function fmtDate(r){
  if(!r)return'';
  if(typeof r==='string'&&r.startsWith('/Date(')){
    const ms=parseInt(r.replace('/Date(','').split('+')[0].split(')')[0],10);
    return new Date(ms).toLocaleString();
  }
  return r;
}
function sevTag(s){return `<span class="sev-tag ${s}">${SEV[s]||s}</span>`;}
function infoRow(label,val){return val!=null&&val!==''?`<div class="info-row"><span class="info-label">${esc(label)}</span><span class="info-val">${esc(String(val))}</span></div>`:'';}
async function api(url,opts){try{const r=await fetch(url,opts);return await r.json();}catch{return null;}}

// ═══════════════════════════════════════════════════
// OVERVIEW / FINDINGS
// ═══════════════════════════════════════════════════
let activeFilter='all', activeCat='all';
document.querySelectorAll('.chip[data-filter]').forEach(c=>{
  c.addEventListener('click',()=>{
    document.querySelectorAll('.chip[data-filter]').forEach(x=>x.classList.remove('active'));
    c.classList.add('active'); activeFilter=c.dataset.filter; renderFindingsList();
  });
});
document.querySelectorAll('.hero-count').forEach(h=>{
  h.addEventListener('click',()=>{
    document.querySelectorAll('.chip[data-filter]').forEach(x=>x.classList.toggle('active',x.dataset.filter===h.dataset.filter));
    activeFilter=h.dataset.filter; renderFindingsList(); switchView('overview');
  });
});
document.getElementById('filter-category')?.addEventListener('change',e=>{activeCat=e.target.value;renderFindingsList();});

function renderCounts(c){['critical','high','medium','low','info'].forEach(s=>{ document.getElementById(`count-${s}`).textContent=c[s]??0; });}

function renderNavBadges(findings){
  document.getElementById('badge-overview').textContent=findings.length||'';
  const cats={network:0,system:0,malware:0,logs:0,hardware:0,drivers:0};
  findings.forEach(f=>{if(cats[f.category]!==undefined&&(f.severity==='critical'||f.severity==='high'))cats[f.category]++;});
  Object.entries(cats).forEach(([cat,n])=>{const el=document.getElementById(`badge-${cat}`);if(!el)return;el.textContent=n||'';el.classList.toggle('hot',n>0);});
}

function renderFindingsList(){
  const list=document.getElementById('findings-list');
  let items=lastFindings;
  if(activeFilter!=='all') items=items.filter(f=>f.severity===activeFilter);
  if(activeCat!=='all') items=items.filter(f=>f.category===activeCat);
  if(!items.length){list.innerHTML='<p class="empty-state">No findings for this filter.</p>';return;}
  list.innerHTML=items.map(f=>`
    <div class="finding ${f.severity}" onclick="showFindingDetail(${JSON.stringify(f).replace(/"/g,'&quot;')})">
      <div class="finding-top">${sevTag(f.severity)}<span class="finding-title">${esc(f.title)}</span><span class="finding-cat">${CAT[f.category]||f.category}</span></div>
      <div class="finding-detail">${esc(f.detail)}</div>
      <div class="finding-rec">${esc(f.recommendation)}</div>
      ${f.reference?`<a class="finding-ref" href="${esc(f.reference)}" target="_blank" rel="noopener">Learn more →</a>`:''}
    </div>`).join('');
}

window.showFindingDetail=function(f){
  document.getElementById('modal-content').innerHTML=`
    <h3 style="margin-top:0">${esc(f.title)}</h3>
    <p>${sevTag(f.severity)} <span style="color:var(--muted);font-size:12px">${CAT[f.category]||f.category}</span></p>
    <p><strong>Detail:</strong> ${esc(f.detail)}</p>
    <p><strong>Recommendation:</strong> ${esc(f.recommendation)}</p>
    ${f.evidence?.length?`<p><strong>Evidence:</strong><br><code>${f.evidence.map(esc).join('<br>')}</code></p>`:''}
    ${f.reference?`<p><a href="${esc(f.reference)}" target="_blank" rel="noopener">🔗 ${esc(f.reference)}</a></p>`:''}`;
  document.getElementById('detail-modal').classList.remove('hidden');
};
document.getElementById('modal-close')?.addEventListener('click',()=>document.getElementById('detail-modal').classList.add('hidden'));
document.getElementById('detail-modal')?.addEventListener('click',e=>{if(e.target===e.currentTarget)e.currentTarget.classList.add('hidden');});

function renderFindings(findings){lastFindings=findings;renderNavBadges(findings);renderFindingsList();}

// ═══════════════════════════════════════════════════
// FULL SCAN
// ═══════════════════════════════════════════════════
document.getElementById('run-scan').addEventListener('click',async()=>{
  const btn=document.getElementById('run-scan');
  btn.disabled=true;btn.textContent='Scanning…';
  document.getElementById('scan-meta').textContent='Scan in progress…';
  const data=await api('/api/scan',{method:'POST'});
  if(!data){document.getElementById('scan-meta').textContent='Error — is app.py running?';btn.disabled=false;btn.textContent='▶ Run Full Scan';return;}
  renderCounts(data.counts||{});renderFindings(data.findings||[]);
  const d=data.details||{};
  renderPorts(d.network_scan?.listening_ports);
  renderDefenderBox(d.defender_scan?.defender_status);
  renderClamavBox(d.clamav_scan?.clamav);
  const when=data.ran_at?new Date(data.ran_at).toLocaleString():'';
  lastScanMeta={when,total:data.total,isAdmin:data.is_admin,counts:data.counts};
  document.getElementById('scan-meta').textContent=`Last scan: ${when} · ${data.total} finding(s) · ${data.is_admin?'Administrator':'Limited'}`;
  btn.disabled=false;btn.textContent='▶ Run Full Scan';
});

// ═══════════════════════════════════════════════════
// NETWORK
// ═══════════════════════════════════════════════════
const RISKY=new Set([21,23,135,139,445,1433,3306,3389,5900]);
async function loadPorts(){
  const scan=await api('/api/scan');
  renderPorts(scan?.details?.network_scan?.listening_ports||[]);
}
function renderPorts(ports=[]){
  const f=document.getElementById('port-filter')?.value.toLowerCase()||'';
  const rows=ports.filter(p=>!f||String(p.port).includes(f)||p.process?.toLowerCase().includes(f));
  document.querySelector('#ports-table tbody').innerHTML=rows.map(p=>`
    <tr class="${RISKY.has(p.port)?'tr-high':''}">
      <td>${p.port}</td><td>${esc(p.address)}</td><td>${esc(p.process)}</td><td>${p.pid??''}</td>
      <td>${RISKY.has(p.port)?sevTag('high'):''}</td></tr>`).join('')||'<tr><td colspan="5" class="note">No data — run a full scan first.</td></tr>';
}
document.getElementById('port-filter')?.addEventListener('input',()=>renderPorts());
document.getElementById('refresh-ports')?.addEventListener('click',loadPorts);

async function loadConnections(){
  const d=await api('/api/network/connections');
  allConns=d?.connections||[];renderConnections();
}
function renderConnections(){
  const ext=document.getElementById('ext-only')?.checked;
  const f=document.getElementById('conn-filter')?.value.toLowerCase()||'';
  const rows=(ext?allConns.filter(c=>c.is_external):allConns).filter(c=>!f||c.remote_ip?.includes(f)||c.process?.toLowerCase().includes(f));
  document.querySelector('#conns-table tbody').innerHTML=rows.map(c=>`
    <tr class="${c.alert?'tr-critical':''}">
      <td>${esc(c.process)}</td><td>${c.pid}</td><td>${esc(c.local_addr)}</td>
      <td>${esc(c.remote_ip)}</td><td>${c.remote_port}</td><td>${esc(c.hostname)}</td>
      <td>${esc(c.status)}</td><td>${c.alert?sevTag('critical')+''+esc(c.alert):''}</td></tr>`).join('')||'<tr><td colspan="8" class="note">No connections.</td></tr>';
}
document.getElementById('ext-only')?.addEventListener('change',renderConnections);
document.getElementById('conn-filter')?.addEventListener('input',renderConnections);
document.getElementById('refresh-conns')?.addEventListener('click',loadConnections);
document.getElementById('refresh-fw')?.addEventListener('click',async()=>{
  const d=await api('/api/network/firewall');const f=document.getElementById('fw-filter')?.value.toLowerCase()||'';
  const rows=(d?.rules||[]).filter(r=>!f||r.name?.toLowerCase().includes(f));
  document.querySelector('#fw-table tbody').innerHTML=rows.map(r=>`<tr><td>${esc(r.name)}</td><td>${esc(r.action)}</td><td>${esc(r.profile)}</td></tr>`).join('')||'<tr><td colspan="3" class="note">No data.</td></tr>';
});
document.getElementById('fw-filter')?.addEventListener('input',()=>document.getElementById('refresh-fw')?.click());
document.getElementById('refresh-netio')?.addEventListener('click',async()=>{
  const d=await api('/api/network/perprocess');
  document.querySelector('#netio-table tbody').innerHTML=(d?.io||[]).map(p=>`<tr><td>${esc(p.name)}</td><td>${p.pid}</td><td>${p.read_mb}</td><td>${p.write_mb}</td></tr>`).join('')||'<tr><td colspan="4" class="note">No data.</td></tr>';
});

// ═══════════════════════════════════════════════════
// MALWARE — SCAN PROFILES
// ═══════════════════════════════════════════════════
let selectedProfile='quick';
document.querySelectorAll('.profile-card').forEach(c=>{
  c.addEventListener('click',()=>{
    document.querySelectorAll('.profile-card').forEach(x=>x.classList.remove('active'));
    c.classList.add('active'); selectedProfile=c.dataset.profile;
    document.getElementById('custom-path-row').style.display=selectedProfile==='custom'?'flex':'none';
  });
});
document.getElementById('browse-quick-temp')?.addEventListener('click',()=>{document.getElementById('custom-scan-path').value='%TEMP%';});
document.getElementById('browse-quick-dl')?.addEventListener('click',()=>{
  document.getElementById('custom-scan-path').value='%USERPROFILE%\\Downloads';
});

document.getElementById('start-av-scan')?.addEventListener('click',async()=>{
  const btn=document.getElementById('start-av-scan');
  const note=document.getElementById('av-scan-note');
  const prog=document.getElementById('av-scan-progress');
  const res=document.getElementById('av-scan-results');
  const extra=selectedProfile==='custom'?[document.getElementById('custom-scan-path').value.trim()]:[];
  btn.disabled=true; note.textContent=''; prog.style.display='flex'; res.innerHTML='';
  const msgs=['Initializing scan engine…','Scanning files…','Checking signatures…','Finalizing results…'];
  let mi=0;const tick=setInterval(()=>{document.getElementById('av-scan-progress-msg').textContent=msgs[mi++%msgs.length];},4000);
  const d=await api('/api/clamav/scan/profile',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({profile:selectedProfile,extra_paths:extra})});
  clearInterval(tick); prog.style.display='none'; btn.disabled=false;
  if(!d||d.error){note.textContent=d?.error||'Scan failed.';return;}
  const infected=d.infected||[];
  note.textContent=`Scanned: ${(d.scanned||[]).join(', ')} · ${infected.length} threat(s) found`;
  res.innerHTML=infected.length
    ?`<div class="finding critical"><div class="finding-top">${sevTag('critical')}<span class="finding-title">${infected.length} infected file(s) detected</span></div>
       <table class="data-table" style="margin-top:8px"><thead><tr><th>File</th><th>Signature</th></tr></thead><tbody>
       ${infected.map(i=>`<tr><td class="mono">${esc(i.file)}</td><td>${esc(i.signature)}</td></tr>`).join('')}
       </tbody></table></div>`
    :'<div class="finding low"><div class="finding-top">'+sevTag('low')+'<span class="finding-title">No threats detected</span></div></div>';
});

async function loadDbStats(){
  const d=await api('/api/clamav/profiles');
  const box=document.getElementById('db-stats-box');
  if(!d){box.textContent='Could not load.';return;}
  const stats=d.db_stats||{};
  if(!stats.installed){box.textContent='ClamAV not installed.';return;}
  const files=stats.db_files||[];
  box.innerHTML=files.length
    ?files.map(f=>`${f.name} — ${f.size_mb} MB — ${f.age_days} day(s) old (${f.modified})`).join('\n')
    :'No .cvd/.cld files found. Run freshclam to update.';
}

// DEFENDER
async function loadDefenderStatus(){const scan=await api('/api/scan');renderDefenderBox(scan?.details?.defender_scan?.defender_status);}
function renderDefenderBox(s){document.getElementById('defender-status').textContent=s&&Object.keys(s).length?JSON.stringify(s,null,2):'No data (Administrator needed?).';}
document.getElementById('run-defender-scan')?.addEventListener('click',async()=>{
  const btn=document.getElementById('run-defender-scan');btn.disabled=true;
  const d=await api('/api/defender/scan',{method:'POST'});
  document.getElementById('defender-scan-note').textContent=d?.note||d?.error||'';btn.disabled=false;
});

// CLAMAV STATUS
async function loadClamavStatus(){const d=await api('/api/clamav/status');renderClamavBox(d);}
function renderClamavBox(d){
  const box=document.getElementById('clamav-status');const pill=document.getElementById('clamav-installed-pill');
  if(!d?.installed){pill.textContent='Not installed';pill.className='pill warn-pill';box.textContent='ClamAV not found. Download: https://www.clamav.net/download';return;}
  pill.textContent='Installed';pill.className='pill ok-pill';
  const age=d.db_age_days==null?'Database age unknown':`Database: ${d.db_age_days} day(s) old (${d.db_file||''})`;
  box.textContent=`clamscan: ${d.clamscan}\nfreshclam: ${d.freshclam}\n${age}`;
}
document.getElementById('clamav-update-btn')?.addEventListener('click',async()=>{
  const btn=document.getElementById('clamav-update-btn');btn.disabled=true;
  const d=await api('/api/clamav/update',{method:'POST'});
  document.getElementById('clamav-note').textContent=d?.note||d?.error||'';btn.disabled=false;
  setTimeout(loadDbStats,3000);
});

// HASH CHECK
document.getElementById('mb-key-save')?.addEventListener('click',async()=>{
  const k=document.getElementById('mb-key-input').value.trim();
  await api('/api/settings',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({malwarebazaar_auth_key:k})});
  document.getElementById('hash-note').textContent='Key saved.';
});
document.getElementById('run-hash-check')?.addEventListener('click',async()=>{
  const btn=document.getElementById('run-hash-check');btn.disabled=true;
  document.getElementById('hash-note').textContent='Checking…';
  const d=await api('/api/hash/check',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({limit:25})});
  document.querySelector('#hash-table tbody').innerHTML=(d?.results||[]).map(r=>{
    const st=r.malware?sevTag('critical'):r.clean?sevTag('low'):'<span class="sev-tag info">Unknown</span>';
    return `<tr class="${r.malware?'tr-critical':''}"><td>${esc(r.name)}</td><td>${r.pid}</td>
      <td class="mono" style="max-width:220px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${esc(r.path)}">${esc(r.path)}</td>
      <td class="mono" style="font-size:11px">${esc(r.sha256||'')}</td><td>${st}</td></tr>`;
  }).join('')||'<tr><td colspan="5" class="note">No data</td></tr>';
  document.getElementById('hash-note').textContent=d?.has_key?'':`No API key — hashes computed but not checked online.`;
  btn.disabled=false;
});

// ═══════════════════════════════════════════════════
// REGISTRY
// ═══════════════════════════════════════════════════
async function scanRegistry(){
  document.getElementById('registry-note').textContent='Scanning…';
  const d=await api('/api/registry/scan');
  document.getElementById('registry-findings').innerHTML=(d?.findings||[]).map(f=>`
    <div class="finding ${f.severity}"><div class="finding-top">${sevTag(f.severity)}<span class="finding-title">${esc(f.title)}</span></div>
    <div class="finding-detail">${esc(f.detail)}</div><div class="finding-rec">${esc(f.recommendation)}</div></div>`).join('')||'<p class="empty-state">No suspicious autorun entries.</p>';
  const filter=document.getElementById('reg-filter')?.value.toLowerCase()||'';
  const rows=(d?.autoruns||[]).filter(a=>!filter||a.name?.toLowerCase().includes(filter)||a.value?.toLowerCase().includes(filter));
  document.querySelector('#registry-table tbody').innerHTML=rows.map(a=>`
    <tr class="${a.reasons?.length?'tr-high':''}">
      <td class="mono" style="font-size:10.5px;max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${esc(a.label)}">${esc(a.label)}</td>
      <td>${esc(a.name)}</td>
      <td class="mono" style="max-width:240px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${esc(a.value)}">${esc(a.value)}</td>
      <td>${a.exists===true?'<span style="color:var(--accent)">✓</span>':a.exists===false?'<span style="color:var(--critical)">✗ Missing</span>':'–'}</td>
      <td>${a.reasons?.length?sevTag('high')+' '+esc(a.reasons[0]):''}</td></tr>`).join('')||'<tr><td colspan="5" class="note">No entries.</td></tr>';
  document.getElementById('registry-note').textContent=`${(d?.autoruns||[]).length} entries found.`;
}
document.getElementById('refresh-registry')?.addEventListener('click',scanRegistry);
document.getElementById('reg-filter')?.addEventListener('input',scanRegistry);

// ═══════════════════════════════════════════════════
// FILE SCANNER
// ═══════════════════════════════════════════════════
const HOME='%USERPROFILE%';
document.getElementById('filescan-temp')?.addEventListener('click',()=>{document.getElementById('filescan-path').value='%TEMP%';});
document.getElementById('filescan-downloads')?.addEventListener('click',()=>{document.getElementById('filescan-path').value=HOME+'\\Downloads';});
document.getElementById('filescan-startup')?.addEventListener('click',()=>{document.getElementById('filescan-path').value=HOME+'\\AppData\\Roaming\\Microsoft\\Windows\\Start Menu\\Programs\\Startup';});
document.getElementById('run-filescan')?.addEventListener('click',async()=>{
  const folder=document.getElementById('filescan-path').value.trim();
  if(!folder){document.getElementById('filescan-note').textContent='Enter a path.';return;}
  const btn=document.getElementById('run-filescan');btn.disabled=true;
  document.getElementById('filescan-note').textContent='Scanning…';
  const d=await api('/api/filescan',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({folder})});
  if(d?.error){document.getElementById('filescan-note').textContent=d.error;btn.disabled=false;return;}
  const allF=[...(d?.findings||[])];
  (d?.clamav_infected||[]).forEach(i=>allF.push({severity:'critical',title:`ClamAV: ${i.signature}`,detail:i.file,recommendation:'Quarantine or delete immediately.'}));
  document.getElementById('filescan-findings').innerHTML=allF.map(f=>`
    <div class="finding ${f.severity}"><div class="finding-top">${sevTag(f.severity)}<span class="finding-title">${esc(f.title)}</span></div>
    <div class="finding-detail">${esc(f.detail)}</div><div class="finding-rec">${esc(f.recommendation)}</div></div>`).join('')||'<p class="empty-state">No suspicious files found.</p>';
  const suspicious=(d?.files||[]).filter(f=>f.flags?.length);
  document.querySelector('#filescan-table tbody').innerHTML=suspicious.map(f=>`
    <tr class="tr-high"><td class="mono" style="max-width:280px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${esc(f.path)}">${esc(f.name)}</td>
    <td>${Math.round(f.size/1024)} KB</td>
    <td>${(f.flags||[]).map(flag=>sevTag('high')+' '+esc(flag)).join(' ')}</td>
    <td class="mono" style="font-size:10px">${esc(f.sha256||'')}</td></tr>`).join('')||'<tr><td colspan="4" class="note">No flagged files.</td></tr>';
  document.getElementById('filescan-note').textContent=`Done — ${d.total_files} files checked, ${allF.length} issue(s).`;
  btn.disabled=false;
});

// ═══════════════════════════════════════════════════
// EVENT LOGS (expanded detail panel)
// ═══════════════════════════════════════════════════
async function loadLogs(){
  const note=document.getElementById('logs-note');note.textContent='Loading…';
  const d=await api('/api/logs');
  allLogEntries=d?.entries||[];renderLogs();
  note.textContent=d?.error||`${allLogEntries.length} entries`;
}
function logSev(level){
  if(!level)return'info';const l=level.toLowerCase();
  if(l.includes('critical'))return'critical';
  if(l.includes('error'))return'high';
  if(l.includes('warning'))return'medium';
  return'info';
}
function renderLogs(){
  const lf=document.getElementById('logs-filter-level')?.value||'all';
  const llog=document.getElementById('logs-filter-log')?.value||'all';
  const tf=document.getElementById('logs-filter-text')?.value.toLowerCase()||'';
  const rows=allLogEntries.filter(e=>{
    if(lf!=='all'&&e.LevelDisplayName!==lf)return false;
    if(llog!=='all'&&e.LogName!==llog)return false;
    if(tf&&!(e.ProviderName||'').toLowerCase().includes(tf)&&!(e.Message||'').toLowerCase().includes(tf))return false;
    return true;
  });
  document.querySelector('#logs-table tbody').innerHTML=rows.map((e,i)=>{
    const sev=logSev(e.LevelDisplayName);const rc=sev==='critical'?'tr-critical':sev==='high'?'tr-high':'';
    return`<tr class="${rc}">
      <td>${esc(fmtDate(e.TimeCreated))}</td>
      <td>${sev!=='info'?sevTag(sev):''} ${esc(e.LevelDisplayName||'')}</td>
      <td>${esc(e.LogName||'')}</td><td>${esc(e.ProviderName||'')}</td>
      <td class="mono">${esc(String(e.Id||''))}</td>
      <td title="${esc(e.Message||'')}">${esc(e.Message||'')}</td>
      <td><button class="chip" onclick="showLogDetail(${i})">Detail</button></td></tr>`;
  }).join('')||'<tr><td colspan="7" class="note">No entries</td></tr>';
}
window.showLogDetail=function(i){
  const rows=allLogEntries.filter(e=>{
    const lf=document.getElementById('logs-filter-level')?.value||'all';
    const llog=document.getElementById('logs-filter-log')?.value||'all';
    const tf=document.getElementById('logs-filter-text')?.value.toLowerCase()||'';
    if(lf!=='all'&&e.LevelDisplayName!==lf)return false;
    if(llog!=='all'&&e.LogName!==llog)return false;
    if(tf&&!(e.ProviderName||'').toLowerCase().includes(tf)&&!(e.Message||'').toLowerCase().includes(tf))return false;
    return true;
  });
  const e=rows[i];if(!e)return;
  document.getElementById('modal-content').innerHTML=`
    <h3 style="margin-top:0">Event Detail</h3>
    ${infoRow('Time',fmtDate(e.TimeCreated))}
    ${infoRow('Level',e.LevelDisplayName)}
    ${infoRow('Log',e.LogName)}
    ${infoRow('Source',e.ProviderName)}
    ${infoRow('Event ID',e.Id)}
    ${infoRow('Computer',e.MachineName)}
    ${infoRow('Task',e.TaskDisplayName)}
    ${infoRow('Keywords',e.Keywords)}
    <div style="margin-top:10px"><strong>Full message:</strong><pre class="raw-block" style="margin-top:6px;white-space:pre-wrap;font-size:11.5px">${esc(e.Message||'(empty)')}</pre></div>`;
  document.getElementById('detail-modal').classList.remove('hidden');
};
['refresh-logs','logs-filter-level','logs-filter-log','logs-filter-text'].forEach(id=>{
  const el=document.getElementById(id);
  if(!el)return;
  el.addEventListener(id==='refresh-logs'?'click':'input',id==='refresh-logs'?loadLogs:renderLogs);
});

// ═══════════════════════════════════════════════════
// MONITORING
// ═══════════════════════════════════════════════════
const MAX_H=50;let cpuH=[],ramH=[];
function drawChart(canvas,data,color){
  if(!canvas)return;const ctx=canvas.getContext('2d');
  const W=canvas.clientWidth||240,H=46;canvas.width=W;canvas.height=H;
  ctx.clearRect(0,0,W,H);if(data.length<2)return;
  ctx.strokeStyle=color;ctx.lineWidth=1.5;ctx.beginPath();
  data.forEach((v,i)=>{const x=(i/(MAX_H-1))*W,y=H-(Math.min(v,100)/100)*H;i===0?ctx.moveTo(x,y):ctx.lineTo(x,y);});
  ctx.stroke();
  const g=ctx.createLinearGradient(0,0,0,H);g.addColorStop(0,color+'30');g.addColorStop(1,color+'00');
  ctx.fillStyle=g;ctx.lineTo(W,H);ctx.lineTo(0,H);ctx.closePath();ctx.fill();
}
function renderMonitorAlerts(alerts){
  document.getElementById('monitor-alerts-bar').innerHTML=(alerts||[]).map(a=>`
    <div class="alert-banner ${a.level==='warning'?'warn':''}">
      ${sevTag(a.level==='critical'?'critical':'medium')} <strong>${esc(a.metric)}</strong> is at ${parseFloat(a.value).toFixed(0)}% (threshold: ${a.threshold}%)
    </div>`).join('');
  document.getElementById('mc-cpu')?.classList.toggle('mc-alert',alerts?.some(a=>a.metric.includes('CPU'))??false);
  document.getElementById('mc-ram')?.classList.toggle('mc-alert',alerts?.some(a=>a.metric.includes('RAM'))??false);
}
async function pollMetrics(){
  const d=await api('/api/monitor/system');if(!d||d.error)return;
  document.getElementById('metric-cpu').textContent=`${parseFloat(d.cpu_percent).toFixed(0)}%`;
  document.getElementById('metric-ram').textContent=`${parseFloat(d.ram_percent).toFixed(0)}%`;
  document.getElementById('metric-ram').title=`${d.ram_used_gb}/${d.ram_total_gb} GB`;
  document.getElementById('metric-swap').textContent=`${d.swap_used_gb}/${d.swap_total_gb} GB (${parseFloat(d.swap_percent).toFixed(0)}%)`;
  document.getElementById('metric-net').textContent=`↑ ${d.net_sent_mb} MB\n↓ ${d.net_recv_mb} MB\nPkts: ${d.net_pkts_sent}/${d.net_pkts_recv}`;
  cpuH.push(d.cpu_percent);ramH.push(d.ram_percent);
  if(cpuH.length>MAX_H)cpuH.shift();if(ramH.length>MAX_H)ramH.shift();
  drawChart(document.getElementById('chart-cpu'),cpuH,'#38D9A9');
  drawChart(document.getElementById('chart-ram'),ramH,'#4FA7E8');
  document.getElementById('disk-bars').innerHTML=(d.disks||[]).map(dk=>{
    const cls=dk.percent>=90?'danger':dk.percent>=75?'warn':'';
    const io=dk.read_mb!=null?` R:${dk.read_mb} W:${dk.write_mb} MB`:'';
    return`<div class="disk-bar-row">
      <div class="disk-bar-label"><span>${esc(dk.mountpoint)} (${esc(dk.fstype||'')})</span><span>${dk.used_gb}/${dk.total_gb} GB · ${dk.percent}%${io}</span></div>
      <div class="disk-bar-track"><div class="disk-bar-fill ${cls}" style="width:${dk.percent}%"></div></div></div>`;
  }).join('');
  document.getElementById('net-interfaces').innerHTML=Object.entries(d.interfaces||{}).map(([n,s])=>
    `<span style="margin-right:14px">${esc(n)} — ${s.isup?'<span style="color:var(--accent)">UP</span>':'DOWN'}${s.speed?` ${s.speed} Mbps`:''}</span>`).join('');
  renderMonitorAlerts(d.alerts);
}
let procFilter='';
document.getElementById('proc-filter')?.addEventListener('input',e=>{procFilter=e.target.value.toLowerCase();});
async function pollProcs(){
  const d=await api(`/api/monitor/processes?sort=${processSort}&limit=50`);
  document.querySelector('#process-table tbody').innerHTML=(d?.processes||[]).filter(p=>!procFilter||p.name.toLowerCase().includes(procFilter)).map(p=>`
    <tr><td>${esc(p.name)}</td><td>${p.pid}</td><td class="mono" style="font-size:11px">${esc(p.user)}</td>
    <td style="color:${p.cpu_percent>50?'var(--critical)':p.cpu_percent>20?'var(--high)':'inherit'}">${p.cpu_percent}</td>
    <td style="color:${p.memory_mb>1000?'var(--high)':'inherit'}">${p.memory_mb}</td>
    <td>${esc(p.status)}</td>
    <td class="mono" style="max-width:240px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${esc(p.exe)}">${esc(p.exe)}</td></tr>`).join('')||'<tr><td colspan="7" class="note">No data</td></tr>';
}
['sort-cpu','sort-mem'].forEach(id=>{document.getElementById(id)?.addEventListener('click',()=>{
  processSort=document.getElementById(id).dataset.sort;
  document.getElementById('sort-cpu').classList.toggle('active',processSort==='cpu');
  document.getElementById('sort-mem').classList.toggle('active',processSort==='memory');
  pollProcs();
});});
function startMonitor(){if(monitorTimer)return;pollMetrics();pollProcs();monitorTimer=setInterval(()=>{if(document.getElementById('auto-refresh')?.checked!==false){pollMetrics();pollProcs();}},3000);}
function stopMonitor(){if(monitorTimer){clearInterval(monitorTimer);monitorTimer=null;}}

// ═══════════════════════════════════════════════════
// HARDWARE
// ═══════════════════════════════════════════════════
async function loadDisks(){
  const btn=document.getElementById('refresh-disks');if(btn)btn.disabled=true;
  const d=await api('/api/hardware/disks');
  document.getElementById('disk-findings').innerHTML=(d?.findings||[]).map(f=>`
    <div class="finding ${f.severity}"><div class="finding-top">${sevTag(f.severity)}<span class="finding-title">${esc(f.title)}</span></div>
    <div class="finding-detail">${esc(f.detail)}</div><div class="finding-rec">${esc(f.recommendation)}</div></div>`).join('')||'';
  const smart=d?.smart||[];
  document.querySelector('#disks-table tbody').innerHTML=(d?.disks||[]).map(dk=>{
    const sm=smart.find(s=>s.InstanceName?.toLowerCase().includes(dk.FriendlyName?.toLowerCase()||'__none__'));
    const pred=sm?.PredictFailure?`<span style="color:var(--critical)">⚠ FAILURE PREDICTED</span>`:'<span style="color:var(--accent)">OK</span>';
    const hcls=String(dk.HealthStatus||'').toLowerCase()==='unhealthy'?'tr-critical':String(dk.HealthStatus||'').toLowerCase()==='warning'?'tr-high':'';
    return`<tr class="${hcls}"><td>${esc(dk.FriendlyName||dk.friendly_name||'')}</td><td>${esc(dk.MediaType||dk.media_type||'')}</td>
      <td>${dk.size_gb||0}</td>
      <td>${esc(dk.HealthStatus||dk.health_status||'')}</td>
      <td>${esc(dk.OperationalStatus||dk.operational_status||'')}</td>
      <td>${pred}</td></tr>`;
  }).join('')||'<tr><td colspan="6" class="note">No disk data (Administrator needed?).</td></tr>';
  if(btn)btn.disabled=false;
}
document.getElementById('refresh-disks')?.addEventListener('click',loadDisks);

document.getElementById('refresh-ram')?.addEventListener('click',async()=>{
  const d=await api('/api/hardware/ram');
  document.getElementById('ram-findings').innerHTML=(d?.findings||[]).map(f=>`
    <div class="finding ${f.severity}"><div class="finding-top">${sevTag(f.severity)}<span class="finding-title">${esc(f.title)}</span></div>
    <div class="finding-detail">${esc(f.detail)}</div></div>`).join('')||'';
  document.querySelector('#ram-table tbody').innerHTML=(d?.modules||[]).map(m=>`
    <tr><td>${esc(m.DeviceLocator||m.device_locator||'')}</td>
    <td>${m.capacity_gb||0} GB</td><td>${m.ConfiguredClockSpeed||m.Speed||0} MHz</td>
    <td>${esc(m.memory_type_name||'')}</td><td>${esc(m.form_factor_name||'')}</td>
    <td>${esc(m.Manufacturer||m.manufacturer||'')}</td><td class="mono" style="font-size:11px">${esc(m.PartNumber||m.part_number||'')}</td></tr>`).join('')||'<tr><td colspan="7" class="note">No RAM data.</td></tr>';
});

document.getElementById('refresh-gpu')?.addEventListener('click',async()=>{
  const d=await api('/api/hardware/gpu');
  document.getElementById('gpu-findings').innerHTML=(d?.findings||[]).map(f=>`
    <div class="finding ${f.severity}"><div class="finding-top">${sevTag(f.severity)}<span class="finding-title">${esc(f.title)}</span></div>
    <div class="finding-detail">${esc(f.detail)}</div></div>`).join('')||'';
  document.getElementById('gpu-cards').innerHTML=(d?.gpus||[]).map(g=>`
    <div class="gpu-card">
      <div class="card-title">${esc(g.Name||g.name||'GPU')}</div>
      ${infoRow('VRAM',g.vram_gb+' GB')}${infoRow('Video Processor',g.VideoProcessor||g.video_processor||'')}
      ${infoRow('Driver Version',g.DriverVersion||g.driver_version||'')}
      ${infoRow('Resolution',g.CurrentHorizontalResolution&&g.CurrentVerticalResolution?`${g.CurrentHorizontalResolution}×${g.CurrentVerticalResolution}`:'')}
      ${infoRow('Refresh Rate',g.CurrentRefreshRate?g.CurrentRefreshRate+' Hz':'')}
      ${infoRow('Status',g.Status||g.status||'')}
    </div>`).join('')||'<p class="empty-state">No GPU data.</p>';
});

// STRESS TEST
document.getElementById('start-stress')?.addEventListener('click',async()=>{
  const path=document.getElementById('stress-path').value.trim()||'%TEMP%';
  const size=parseInt(document.getElementById('stress-size').value);
  const box=document.getElementById('stress-result');const btn=document.getElementById('start-stress');
  btn.disabled=true;box.textContent='Starting stress test…';
  const d=await api('/api/hardware/stress/start',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({path,size_mb:size})});
  if(!d?.started){box.textContent=d?.error||'Failed to start.';btn.disabled=false;return;}
  box.textContent=`Running ${size} MB write+read test on ${path}…`;
  const poll=setInterval(async()=>{
    const s=await api('/api/hardware/stress/status');
    if(s?.running)return;clearInterval(poll);btn.disabled=false;
    if(s?.error){box.textContent=`Error: ${s.error}`;return;}
    const r=s?.result;
    box.textContent=r?`RESULT: ${r.verdict}\nWrite: ${r.write_mb_s} MB/s (${r.write_s}s)\nRead:  ${r.read_mb_s} MB/s (${r.read_s}s)\nPath:  ${r.path}\nSize:  ${r.size_mb} MB`:'No result returned.';
  },1000);
});

// ═══════════════════════════════════════════════════
// DRIVERS
// ═══════════════════════════════════════════════════
async function loadDrivers(){
  const btn=document.getElementById('refresh-drivers');if(btn)btn.disabled=true;
  document.getElementById('drivers-note').textContent='Scanning drivers and hardware IDs…';
  const d=await api('/api/drivers/scan');
  allDrivers=d?.drivers||[];
  document.getElementById('driver-findings').innerHTML=(d?.findings||[]).slice(0,5).map(f=>`
    <div class="finding ${f.severity}"><div class="finding-top">${sevTag(f.severity)}<span class="finding-title">${esc(f.title)}</span></div>
    <div class="finding-detail">${esc(f.detail)}</div>
    ${f.reference?`<a class="finding-ref" href="${esc(f.reference)}" target="_blank" rel="noopener">Download driver →</a>`:''}</div>`).join('')||'';
  renderDrivers();
  document.getElementById('drivers-note').textContent=`${allDrivers.length} drivers found.`;
  if(btn)btn.disabled=false;
}
function renderDrivers(){
  const f=document.getElementById('driver-filter')?.value.toLowerCase()||'';
  const cls=document.getElementById('driver-class-filter')?.value||'all';
  const oldOnly=document.getElementById('driver-old-only')?.checked;
  const rows=allDrivers.filter(d=>{
    if(f&&!(`${d.name||''} ${d.manufacturer||''} ${d.hardware_id||''}`).toLowerCase().includes(f))return false;
    if(cls!=='all'&&d.device_class!==cls)return false;
    if(oldOnly&&!(d.age_days>365*2))return false;
    return true;
  });
  document.querySelector('#drivers-table tbody').innerHTML=rows.map((d,i)=>{
    const old=d.age_days>365*2;const vold=d.age_days>365*3;
    const hwid=d.hardware_id||d.device_id||'';
    const encoded=encodeURIComponent(hwid);
    return`<tr class="${vold?'tr-critical':old?'tr-high':''}">
      <td>${esc(d.name)}</td><td><span class="chip" style="pointer-events:none">${esc(d.device_class||'')}</span></td>
      <td class="mono" style="font-size:11px">${esc(d.version||'')}</td>
      <td>${esc(d.driver_date||'')}</td>
      <td style="color:${vold?'var(--critical)':old?'var(--high)':'inherit'}">${d.age_days!=null?d.age_days+' days':'–'}</td>
      <td>${esc(d.manufacturer||'')}</td>
      <td title="${esc(hwid)}"><span class="mono driver-hwid">${esc(hwid||'Not available')}</span></td>
      <td><div class="driver-actions">${hwid?`<button class="copy-btn" onclick="copyHardwareId(${JSON.stringify(hwid)})">Copy</button><button class="copy-btn web-btn" onclick="searchHardwareId(${JSON.stringify(hwid)})">Web</button>`:'–'}${d.download_url?`<a class="copy-btn" href="${esc(d.download_url)}" target="_blank" rel="noopener">Vendor</a>`:''}</div></td></tr>`;
  }).join('')||'<tr><td colspan="8" class="note">No drivers match filter.</td></tr>';
}
window.copyHardwareId=async function(id){
  try{await navigator.clipboard.writeText(id);toast?.('Hardware ID copied');}catch(e){
    const ta=document.createElement('textarea');ta.value=id;document.body.appendChild(ta);ta.select();document.execCommand('copy');ta.remove();
  }
};
window.searchHardwareId=function(id){window.open('https://www.google.com/search?q='+encodeURIComponent('"'+id+'" driver'),'_blank','noopener');};
['driver-filter','driver-class-filter','driver-old-only'].forEach(id=>{document.getElementById(id)?.addEventListener(id==='driver-old-only'?'change':'input',renderDrivers);});
document.getElementById('refresh-drivers')?.addEventListener('click',loadDrivers);

// ═══════════════════════════════════════════════════
// SYSTEM INFO
// ═══════════════════════════════════════════════════
async function loadSysInfo(){
  const [info,bat]=await Promise.all([api('/api/hardware/info'),api('/api/hardware/battery')]);
  function fill(id,rows){const b=document.querySelector(`#${id} .info-card-body`);if(b)b.innerHTML=rows.join('');}
  const cs=info?.computer||{};
  fill('si-computer',[infoRow('Manufacturer',cs.Manufacturer||cs.manufacturer),infoRow('Model',cs.Model||cs.model),infoRow('System Type',cs.SystemType||cs.system_type),infoRow('Logical CPUs',cs.NumberOfLogicalProcessors||cs.num_logical),infoRow('Total RAM',cs.TotalPhysicalMemory?Math.round((cs.TotalPhysicalMemory||0)/(1024**3))+' GB':'')]);
  const os=info?.os||{};
  fill('si-os',[infoRow('OS',os.Caption||os.caption),infoRow('Version',os.Version||os.version),infoRow('Build',os.BuildNumber||os.build_number),infoRow('Architecture',os.OSArchitecture||os.arch),infoRow('Install Date',fmtDate(os.InstallDate||os.install_date)),infoRow('Last Boot',fmtDate(os.LastBootUpTime||os.last_boot)),infoRow('Free RAM',os.FreePhysicalMemory?Math.round((os.FreePhysicalMemory||0)/1024)+' MB':'')]);
  const cpus=Array.isArray(info?.cpu)?info.cpu:[info?.cpu||{}];
  fill('si-cpu',cpus.flatMap(c=>[infoRow('Name',c.Name||c.name),infoRow('Manufacturer',c.Manufacturer||c.manufacturer),infoRow('Max Speed',c.MaxClockSpeed?c.MaxClockSpeed+' MHz':''),infoRow('Cores',c.NumberOfCores||c.cores),infoRow('Threads',c.NumberOfLogicalProcessors||c.threads),infoRow('L2 Cache',c.L2CacheSize?c.L2CacheSize+' KB':''),infoRow('L3 Cache',c.L3CacheSize?c.L3CacheSize+' KB':''),infoRow('Socket',c.SocketDesignation||c.socket)]));
  const gpus=Array.isArray(info?.gpu)?info.gpu:[info?.gpu||{}];
  fill('si-gpu',gpus.flatMap(g=>[infoRow('Name',g.Name||g.name),infoRow('VRAM',g.vram_gb?g.vram_gb+' GB':''),infoRow('Driver',g.DriverVersion||g.driver_version),infoRow('Resolution',g.CurrentHorizontalResolution?`${g.CurrentHorizontalResolution}×${g.CurrentVerticalResolution}`:'')]));
  const mobo=info?.motherboard||{};
  fill('si-mobo',[infoRow('Manufacturer',mobo.Manufacturer||mobo.manufacturer),infoRow('Product',mobo.Product||mobo.product),infoRow('Version',mobo.Version||mobo.version),infoRow('Serial',mobo.SerialNumber||mobo.serial)]);
  const bios=info?.bios||{};
  fill('si-bios',[infoRow('Manufacturer',bios.Manufacturer||bios.manufacturer),infoRow('Version',bios.SMBIOSBIOSVersion||bios.version),infoRow('Release Date',fmtDate(bios.ReleaseDate||bios.release_date)),infoRow('Serial',bios.SerialNumber||bios.serial)]);
  // RAM summary
  const ramD=await api('/api/hardware/ram');
  const mods=ramD?.modules||[];
  const totalRam=mods.reduce((s,m)=>s+(m.capacity_gb||0),0);
  fill('si-ram-sum',[infoRow('Total',totalRam+' GB'),infoRow('Modules',mods.length),
    ...mods.map((m,i)=>`<div class="info-row"><span class="info-label">Slot ${i+1}</span><span class="info-val mono">${m.capacity_gb}GB ${m.memory_type_name||''} ${m.ConfiguredClockSpeed||m.Speed||0}MHz</span></div>`)]);
  // Battery
  const b=bat?.battery;
  const bcard=document.querySelector('#si-battery .info-card-body');
  if(bcard){
    if(!b){bcard.innerHTML='<p class="note">No battery detected (desktop PC or not detected).</p>';}
    else{
      const hp=b.health_percent;const barcls=hp&&hp<40?'low':'';
      bcard.innerHTML=`${infoRow('Status',b.battery_status_name)}${infoRow('Charge',b.EstimatedChargeRemaining!=null?b.EstimatedChargeRemaining+'%':'')}${infoRow('Run Time',b.EstimatedRunTime&&b.EstimatedRunTime<71582?b.EstimatedRunTime+' min':'Unknown')}${infoRow('Chemistry',b.chemistry_name)}
      ${hp!=null?`<div class="info-row"><span class="info-label">Battery Health</span><span class="info-val" style="color:${hp<40?'var(--critical)':hp<70?'var(--high)':'var(--accent)'}">${hp}%</span></div>
      <div class="battery-bar"><div class="battery-fill ${barcls}" style="width:${hp}%"></div></div>`:''}
      ${infoRow('Design Cap.',b.DesignCapacity?b.DesignCapacity+' mWh':'')}${infoRow('Full Cap.',b.FullChargeCapacity?b.FullChargeCapacity+' mWh':'')}`;
    }
  }
}
document.getElementById('refresh-sysinfo')?.addEventListener('click',loadSysInfo);

// ═══════════════════════════════════════════════════
// FILE WATCH
// ═══════════════════════════════════════════════════
let allWatchEvents=[];
function formatBytes(n){if(n==null)return '—';if(n<1024)return n+' B';if(n<1024**2)return (n/1024).toFixed(1)+' KB';if(n<1024**3)return (n/1024**2).toFixed(1)+' MB';return (n/1024**3).toFixed(2)+' GB';}
async function loadWatchEvents(){
  const d=await api('/api/watch/events');
  allWatchEvents=d?.events||[];
  updateWatchFilters();renderWatchEvents();
  const alert=d?.alert;
  document.getElementById('watch-alert-banner').innerHTML=alert?.active?`<div class="alert-banner">${sevTag('critical')} Possible high-volume file activity: ${esc(alert.recent_count)} events in the last 20 seconds.</div>`:'';
  const pl=document.getElementById('watch-paths-list');
  pl.innerHTML=(d?.watched_paths||[]).map(p=>`<span class="chip-tag">${esc(p)}<button onclick="removeWatchPath('${esc(p)}')">×</button></span>`).join('')||'<span class="note">No paths watched.</span>';
  document.getElementById('watch-note').textContent=`${(d?.watched_paths||[]).length} path(s) watched · ${allWatchEvents.length} recent events`;
}
function updateWatchFilters(){
  const sel=document.getElementById('watch-extension-filter');if(!sel)return;
  const current=sel.value;const exts=[...new Set(allWatchEvents.map(e=>(e.extension||'').toLowerCase()).filter(Boolean))].sort();
  sel.innerHTML='<option value="all">All extensions</option>'+exts.map(x=>`<option value="${esc(x)}">.${esc(x)}</option>`).join('');
  if(exts.includes(current))sel.value=current;
}
function renderWatchEvents(){
  const tf=document.getElementById('watch-type-filter')?.value||'all';
  const ef=document.getElementById('watch-extension-filter')?.value||'all';
  const pf=document.getElementById('watch-path-filter')?.value.toLowerCase()||'';
  const rows=allWatchEvents.filter(e=>{
    if(tf!=='all'&&e.type!==tf)return false;if(ef!=='all'&&(e.extension||'').toLowerCase()!==ef)return false;
    if(pf&&!(`${e.path||''} ${e.name||''} ${e.directory||''}`).toLowerCase().includes(pf))return false;return true;
  });
  const counts={created:0,modified:0,deleted:0,renamed:0};allWatchEvents.forEach(e=>{if(counts[e.type]!=null)counts[e.type]++;});
  document.getElementById('watch-count').textContent=allWatchEvents.length;document.getElementById('watch-created').textContent=counts.created;document.getElementById('watch-modified').textContent=counts.modified;document.getElementById('watch-other').textContent=counts.deleted+counts.renamed;
  document.querySelector('#watch-table tbody').innerHTML=rows.map(e=>`
    <tr class="watch-event-${esc(e.type)}">
      <td>${esc(fmtDate(e.time))}</td><td>${esc(e.type)}</td><td title="${esc(e.path||'')}"><strong>${esc(e.name||'Unknown')}</strong></td>
      <td>.${esc(e.extension||'(none)')}</td><td class="mono">${formatBytes(e.size)}</td><td class="mono" title="${esc(e.directory||'')}">${esc(e.directory||'—')}</td>
      <td class="mono" title="${esc(e.watched||'')}">${esc(e.watched||'—')}</td><td>${e.exists?'Present':'Removed'}</td>
    </tr>`).join('')||'<tr><td colspan="8" class="note">No events match the current filters.</td></tr>';
}
['watch-type-filter','watch-extension-filter'].forEach(id=>document.getElementById(id)?.addEventListener('change',renderWatchEvents));
document.getElementById('watch-path-filter')?.addEventListener('input',renderWatchEvents);
document.getElementById('refresh-watch')?.addEventListener('click',loadWatchEvents);
document.getElementById('clear-watch')?.addEventListener('click',async()=>{await api('/api/watch/clear',{method:'POST'});loadWatchEvents();});
document.getElementById('watch-add-btn')?.addEventListener('click',async()=>{
  const p=document.getElementById('watch-path-input').value.trim();if(!p)return;
  const cfg=await api('/api/watch/config');const paths=[...(cfg?.watched_paths||[]),p];
  await api('/api/watch/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({paths})});
  document.getElementById('watch-path-input').value='';loadWatchEvents();
});
window.removeWatchPath=async function(path){const cfg=await api('/api/watch/config');const paths=(cfg?.watched_paths||[]).filter(p=>p!==path);await api('/api/watch/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({paths})});loadWatchEvents();};

// ═══════════════════════════════════════════════════
// REPORTS
// ═══════════════════════════════════════════════════
function buildTxt(){
  const lines=['ZENITH LOCAL — SECURITY REPORT',`Generated: ${new Date().toLocaleString()}`];
  if(lastScanMeta)lines.push(`Scan: ${lastScanMeta.when} · ${lastScanMeta.total} findings · ${lastScanMeta.isAdmin?'Administrator':'Limited'}`);
  lines.push('\nSUMMARY');['critical','high','medium','low','info'].forEach(s=>lines.push(`  ${SEV[s]}: ${lastScanMeta?.counts?.[s]??0}`));
  lines.push('');
  ['critical','high','medium','low','info'].forEach(sev=>{
    const items=lastFindings.filter(f=>f.severity===sev);if(!items.length)return;
    lines.push(`${SEV[sev].toUpperCase()} (${items.length})\n${'-'.repeat(40)}`);
    items.forEach(f=>{lines.push(`[${CAT[f.category]||f.category}] ${f.title}`);lines.push(`  ${f.detail}`);lines.push(`  → ${f.recommendation}`);if(f.reference)lines.push(`  Ref: ${f.reference}`);lines.push('');});
  });
  return lines.join('\n');
}
function buildHtml(){
  if(!lastFindings.length)return'<p class="empty-state">Run a full scan first.</p>';
  let h=`<h3 style="margin-top:0">Zenith Local — Security Report</h3><p class="note">Generated: ${new Date().toLocaleString()}${lastScanMeta?` · ${lastScanMeta.total} findings`:''}</p>`;
  ['critical','high','medium','low','info'].forEach(sev=>{
    const items=lastFindings.filter(f=>f.severity===sev);if(!items.length)return;
    h+=`<h3>${SEV[sev]} (${items.length})</h3>`;
    items.forEach(f=>{h+=`<div class="report-finding"><strong>[${CAT[f.category]||f.category}] ${esc(f.title)}</strong><br>${esc(f.detail)}<br><span style="color:var(--accent)">→ ${esc(f.recommendation)}</span>${f.reference?`<br><a href="${esc(f.reference)}" target="_blank">${esc(f.reference)}</a>`:''}</div>`;});
  });
  return h;
}
document.getElementById('generate-report-btn')?.addEventListener('click',()=>{document.getElementById('report-preview').innerHTML=buildHtml();document.getElementById('report-note').textContent=lastFindings.length?'Report ready.':'Run a scan first.';});
document.getElementById('print-report-btn')?.addEventListener('click',()=>{if(!lastFindings.length){document.getElementById('report-note').textContent='Generate the report first.';return;}window.print();});
document.getElementById('download-report-btn')?.addEventListener('click',()=>{
  if(!lastFindings.length){document.getElementById('report-note').textContent='Generate the report first.';return;}
  const a=Object.assign(document.createElement('a'),{href:URL.createObjectURL(new Blob([buildTxt()],{type:'text/plain'})),download:`hskich-${new Date().toISOString().slice(0,10)}.txt`});
  document.body.appendChild(a);a.click();a.remove();
});

// ═══════════════════════════════════════════════════
// INIT
// ═══════════════════════════════════════════════════
const iv=document.body.dataset.initialView;
if(iv&&document.getElementById(`view-${iv}`))switchView(iv,false);

// ═══════════════════════════════════════════════════
// AUTO-SCAN
// ═══════════════════════════════════════════════════
async function loadAutoscanStatus(){
  const d = await api('/api/autoscan/status');
  if (!d) return;
  const sel = document.getElementById('autoscan-interval');
  const lbl = document.getElementById('autoscan-label');
  if (d.enabled){
    sel.value = d.interval_min;
    lbl.textContent = `Auto-scan: every ${d.interval_min} min`;
    lbl.style.color = 'var(--accent)';
    if (d.next_run) lbl.title = `Next: ${new Date(d.next_run).toLocaleTimeString()}`;
  } else {
    sel.value = '0';
    lbl.textContent = 'Auto-scan: Off';
    lbl.style.color = '';
  }
}
document.getElementById('autoscan-set')?.addEventListener('click', async () => {
  const min = parseInt(document.getElementById('autoscan-interval').value);
  const d   = await api('/api/autoscan/configure', {
    method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify({interval_minutes: min})
  });
  if (d?.ok) {
    loadAutoscanStatus();
    toast(min > 0 ? `Auto-scan set to every ${min} min` : 'Auto-scan disabled', 'success');
  } else {
    toast(d?.error || 'Failed to configure auto-scan', 'error');
  }
});
// Poll auto-scan status every 30s and update label
setInterval(loadAutoscanStatus, 30_000);

// ═══════════════════════════════════════════════════
// SERVICES
// ═══════════════════════════════════════════════════
let allServices = [];

async function loadServices(){
  const note = document.getElementById('svc-note');
  note.textContent = 'Loading…';
  const q      = document.getElementById('svc-filter')?.value || '';
  const status = document.getElementById('svc-status-filter')?.value || 'all';
  const d = await api(`/api/services/list?q=${encodeURIComponent(q)}&status=${status}`);
  allServices = d?.services || [];
  note.textContent = d?.error || `${allServices.length} services`;
  renderServices();
}

function renderServices(){
  const riskyOnly = document.getElementById('svc-risky-only')?.checked;
  const rows = riskyOnly ? allServices.filter(s=>s.risk) : allServices;
  const tb   = document.querySelector('#services-table tbody');
  if (!tb) return;

  // Risk findings at top
  document.getElementById('svc-findings').innerHTML =
    rows.filter(s=>s.risk==='critical'||s.risk==='high').map(s=>`
      <div class="finding ${s.risk}">
        <div class="finding-top">${sevTag(s.risk)}<span class="finding-title">${esc(s.display)}</span></div>
        <div class="finding-detail">${esc(s.risk_desc||'')}</div>
      </div>`).join('');

  tb.innerHTML = rows.map(s => {
    const statusColor = s.status==='Running'?'var(--accent)':s.status==='Stopped'?'var(--critical)':'var(--muted)';
    const riskTag = s.risk ? sevTag(s.risk) : '';
    return `<tr class="${s.risk==='critical'?'tr-critical':s.risk==='high'?'tr-high':''}">
      <td>${esc(s.display)}</td>
      <td class="mono" style="font-size:11px">${esc(s.name)}</td>
      <td style="color:${statusColor};font-weight:600">${esc(s.status)}</td>
      <td>
        <div class="toggle-btn">
          <button onclick="setSvcStartup('${esc(s.name)}','Automatic')" class="${s.start_type==='Automatic'?'active':''}">Auto</button>
          <button onclick="setSvcStartup('${esc(s.name)}','Manual')" class="${s.start_type==='Manual'?'active':''}">Manual</button>
          <button onclick="setSvcStartup('${esc(s.name)}','Disabled')" class="${s.start_type==='Disabled'?'active':''}">Disabled</button>
        </div>
      </td>
      <td>${riskTag}</td>
      <td>
        <div style="display:flex;gap:6px">
          ${s.status!=='Running'?`<button class="secondary-btn" style="padding:4px 10px;font-size:11.5px" onclick="controlSvc('${esc(s.name)}','start')">▶ Start</button>`:''}
          ${s.status==='Running'?`<button class="secondary-btn" style="padding:4px 10px;font-size:11.5px" onclick="controlSvc('${esc(s.name)}','stop')">⏹ Stop</button>`:''}
          <button class="secondary-btn" style="padding:4px 10px;font-size:11.5px" onclick="controlSvc('${esc(s.name)}','restart')">↺ Restart</button>
        </div>
      </td>
    </tr>`;
  }).join('') || '<tr><td colspan="6" class="note">No services match filter.</td></tr>';
}

window.controlSvc = async function(name, action){
  const d = await api('/api/services/control',{
    method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify({name, action})
  });
  if (d?.ok){ toast(`Service ${action}ed: ${name}`,'success'); loadServices(); }
  else toast(d?.error||'Action failed','error');
};

window.setSvcStartup = async function(name, start_type){
  const d = await api('/api/services/startup',{
    method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify({name, start_type})
  });
  if (d?.ok){ toast(`Startup type set to ${start_type}`,'success'); loadServices(); }
  else toast(d?.error||'Failed','error');
};

document.getElementById('refresh-services')?.addEventListener('click', loadServices);
document.getElementById('svc-filter')?.addEventListener('input', loadServices);
document.getElementById('svc-status-filter')?.addEventListener('change', loadServices);
document.getElementById('svc-risky-only')?.addEventListener('change', renderServices);

// ═══════════════════════════════════════════════════
// FIREWALL
// ═══════════════════════════════════════════════════
async function loadFwProfiles(){
  const d = await api('/api/firewall/profiles');
  const container = document.getElementById('fw-profile-cards');
  if (!container) return;
  const profiles = d?.profiles || {};
  container.innerHTML = ['Domain','Private','Public'].map(name => {
    const on = profiles[name];
    return `<div class="fw-profile-card">
      <div class="profile-name">${name}</div>
      <div class="fw-profile-status ${on?'fw-on':'fw-off'}">${on?'● ON':'● OFF'}</div>
      <div style="display:flex;gap:8px;justify-content:center">
        <button class="secondary-btn" style="padding:6px 14px;font-size:12px" onclick="setFwProfile('${name}',true)">Enable</button>
        <button class="secondary-btn" style="padding:6px 14px;font-size:12px" onclick="setFwProfile('${name}',false)">Disable</button>
      </div>
    </div>`;
  }).join('');
}

window.setFwProfile = async function(name, enabled){
  const d = await api('/api/firewall/profile',{
    method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify({name, enabled})
  });
  if (d?.ok){ toast(`Firewall ${name} profile ${enabled?'enabled':'disabled'}`,'success'); loadFwProfiles(); }
  else toast(d?.error||'Failed (Administrator required)','error');
};

let allFwRules = [];
async function loadFwRules(){
  const note = document.getElementById('fw-rules-note');
  if(note) note.textContent = 'Loading…';
  const q       = document.getElementById('fw-rule-filter')?.value||'';
  const dir     = document.getElementById('fw-dir-filter')?.value||'all';
  const action  = document.getElementById('fw-action-filter')?.value||'all';
  const enOnly  = document.getElementById('fw-enabled-only')?.checked?'true':'false';
  const url     = `/api/firewall/rules?q=${encodeURIComponent(q)}&direction=${dir}&action=${action}&enabled_only=${enOnly}`;
  const d = await api(url);
  allFwRules = d?.rules || [];
  renderFwRules();
  if(note) note.textContent = d?.error || `${allFwRules.length} rules`;
}

function renderFwRules(){
  const tb = document.querySelector('#fw-rules-table tbody');
  if (!tb) return;
  tb.innerHTML = allFwRules.map(r=>{
    const actionColor = r.action==='Allow'?'var(--accent)':'var(--critical)';
    return `<tr>
      <td>${esc(r.display)}</td>
      <td>${esc(r.direction)}</td>
      <td style="color:${actionColor};font-weight:600">${esc(r.action)}</td>
      <td>${esc(r.profile)}</td>
      <td>
        <label style="display:flex;align-items:center;gap:6px;cursor:pointer">
          <input type="checkbox" ${r.enabled?'checked':''} onchange="toggleFwRule('${esc(r.name)}',this.checked)">
          <span style="color:${r.enabled?'var(--accent)':'var(--muted)'};font-size:12px">${r.enabled?'On':'Off'}</span>
        </label>
      </td>
      <td>
        <button class="secondary-btn" style="padding:4px 10px;font-size:11.5px;color:var(--critical)"
          onclick="deleteFwRule('${esc(r.name)}')">✕ Delete</button>
      </td>
    </tr>`;
  }).join('') || '<tr><td colspan="6" class="note">No rules (Administrator required for full list)</td></tr>';
}

window.toggleFwRule = async function(name, enabled){
  const d = await api('/api/firewall/rule/toggle',{
    method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify({name, enabled})
  });
  if (d?.ok) toast(`Rule ${enabled?'enabled':'disabled'}: ${name}`,'success');
  else { toast(d?.error||'Failed','error'); loadFwRules(); }
};

window.deleteFwRule = async function(name){
  if (!confirm(`Delete firewall rule:\n${name}\n\nThis cannot be undone.`)) return;
  const d = await api('/api/firewall/rule/delete',{
    method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify({name})
  });
  if (d?.ok){ toast('Rule deleted','success'); loadFwRules(); }
  else toast(d?.error||'Failed','error');
};

document.getElementById('refresh-fw-profiles')?.addEventListener('click', loadFwProfiles);
document.getElementById('refresh-fw-rules')?.addEventListener('click', loadFwRules);
['fw-rule-filter','fw-dir-filter','fw-action-filter','fw-enabled-only'].forEach(id=>{
  document.getElementById(id)?.addEventListener(id.includes('filter')||id.includes('only')?'input':'change', loadFwRules);
});
document.getElementById('fw-enabled-only')?.addEventListener('change', loadFwRules);

document.getElementById('fw-add-btn')?.addEventListener('click', async()=>{
  const d = await api('/api/firewall/rule/add',{
    method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify({
      display_name:   document.getElementById('fw-new-name').value.trim() || 'New Rule',
      direction:      document.getElementById('fw-new-dir').value,
      action:         document.getElementById('fw-new-action').value,
      protocol:       document.getElementById('fw-new-proto').value,
      port:           document.getElementById('fw-new-port').value || null,
      remote_address: document.getElementById('fw-new-addr').value.trim() || null,
    })
  });
  const note = document.getElementById('fw-add-note');
  if (d?.ok){ note.textContent='Rule added.'; note.style.color='var(--accent)'; toast('Firewall rule added','success'); }
  else { note.textContent = d?.error||'Failed (Administrator required)'; note.style.color='var(--critical)'; }
});

// ═══════════════════════════════════════════════════
// RECOMMENDATIONS
// ═══════════════════════════════════════════════════
async function loadRecommendations(){
  const note = document.getElementById('recs-note');
  const list = document.getElementById('recs-list');
  note.textContent = 'Analyzing…';
  const d = await api('/api/recommendations');
  const recs = d?.recommendations || [];
  note.textContent = d?.based_on_scan
    ? `Based on scan at ${new Date(d.based_on_scan).toLocaleString()}`
    : 'Run a full scan first for accurate recommendations.';
  if (!recs.length){
    list.innerHTML = '<p class="empty-state">No recommendations generated. Run a full scan first.</p>';
    return;
  }
  list.innerHTML = recs.map(r=>`
    <div class="rec-card ${r.priority}">
      <div class="rec-top">${sevTag(r.priority)}<span class="rec-title">${esc(r.title)}</span></div>
      <div class="rec-detail">${esc(r.detail)}</div>
      ${r.triggered_by?`<div class="note" style="margin:4px 0">Triggered by: ${esc(r.triggered_by)}</div>`:''}
      <div class="rec-fix">${esc(r.fix)}</div>
    </div>`).join('');
  document.getElementById('badge-recommendations').textContent = recs.filter(r=>r.priority==='critical'||r.priority==='high').length || '';
  document.getElementById('badge-recommendations').classList.toggle('hot', recs.some(r=>r.priority==='critical'));
}

document.getElementById('refresh-recs')?.addEventListener('click', loadRecommendations);

// ── Hook view switching for new views ───────────────
const _origSwitch = switchView;
// Patch switchView to handle new views
const __patchedSwitch = function(id, push=true){
  _origSwitch(id, push);
  if (id==='services')        loadServices();
  if (id==='firewall')        { loadFwProfiles(); loadFwRules(); }
  if (id==='recommendations') loadRecommendations();
};
// Override — replace the nav listeners
document.querySelectorAll('.nav-item').forEach(ni=>{
  ni.querySelector('.nav-label')?.removeEventListener('click', ()=>{});
  ni.querySelector('.nav-label')?.addEventListener('click', ()=>__patchedSwitch(ni.dataset.view));
  ni.querySelector('.nav-popout')?.addEventListener('click', e=>{
    e.stopPropagation();
    const u=new URL(location.origin+location.pathname);
    u.searchParams.set('view',ni.dataset.view);
    window.open(u,'_blank');
  });
});

// Load autoscan status on startup
loadAutoscanStatus();
