"""ClamAV integration: detect an existing install, report signature database freshness,
trigger an update, and run an on-demand scan.
Same reasoning as Defender: ClamAV is a mature, actively-maintained open-source engine
(clamav.net) - this wraps it rather than reinventing detection logic."""
import glob
import os
import re
import sqlite3
import subprocess
from datetime import datetime
from shutil import which

from . import config_store
from .risk_engine import finding

CANDIDATE_DIRS = [
    r"C:\Program Files\ClamAV",
    r"C:\Program Files (x86)\ClamAV",
    r"C:\ClamAV",
]

INFECTED_RE = re.compile(r"^(.*): (.+) FOUND$", re.MULTILINE)


def _find_binary(name):
    found = which(name)
    if found:
        return found
    for d in CANDIDATE_DIRS:
        candidate = os.path.join(d, name)
        if os.path.exists(candidate):
            return candidate
    return None


def _candidate_db_dirs(install_dir):
    if not install_dir:
        return []
    candidates = []
    for candidate in (
        os.path.join(install_dir, "database"),
        os.path.join(install_dir, "db"),
        os.path.join(install_dir, "main"),
        os.path.join(install_dir, "signatures"),
    ):
        if os.path.isdir(candidate):
            candidates.append(candidate)
    if candidates:
        return candidates
    return [install_dir]


def detect():
    clamscan = _find_binary("clamscan.exe")
    freshclam = _find_binary("freshclam.exe")
    install_dir = os.path.dirname(clamscan) if clamscan else None
    db_path = config_store.get_clamav_db_path() or os.environ.get("CLAMAV_DB_PATH")
    if db_path and os.path.isdir(db_path):
        install_dir = db_path
    return {"clamscan": clamscan, "freshclam": freshclam, "install_dir": install_dir, "db_path": db_path}


def _database_dir(install_dir):
    if not install_dir:
        return None
    for candidate in _candidate_db_dirs(install_dir):
        if os.path.isdir(candidate):
            return candidate
    return install_dir


def database_age_days(install_dir):
    """Find the newest .cvd/.cld signature file and report its age in days."""
    db_dir = _database_dir(install_dir)
    if not db_dir:
        return None, None, []
    files = glob.glob(os.path.join(db_dir, "*.cvd")) + glob.glob(os.path.join(db_dir, "*.cld"))
    if not files:
        # support nested DB subfolders from newer ClamAV installs
        nested = []
        for root, _, _ in os.walk(db_dir):
            nested.extend(glob.glob(os.path.join(root, "*.cvd")))
            nested.extend(glob.glob(os.path.join(root, "*.cld")))
        files = nested
    if not files:
        return None, None, []
    newest = max(files, key=os.path.getmtime)
    age_days = (datetime.now() - datetime.fromtimestamp(os.path.getmtime(newest))).days
    return age_days, os.path.basename(newest), sorted(files, key=os.path.getmtime, reverse=True)[:10]


def run_update(freshclam_path):
    if not freshclam_path:
        return False, "freshclam.exe not found"
    try:
        from .ps import SUBPROCESS_FLAGS
        subprocess.Popen(
            [freshclam_path], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            **SUBPROCESS_FLAGS,
        )
        return True, None
    except (OSError, ValueError) as exc:
        return False, str(exc)


def default_scan_paths():
    home = os.environ.get("USERPROFILE") or os.path.expanduser("~")
    paths = []
    for sub in ("Downloads", "Desktop"):
        p = os.path.join(home, sub)
        if os.path.isdir(p):
            paths.append(p)
    temp = os.environ.get("TEMP")
    if temp and os.path.isdir(temp):
        paths.append(temp)
    return paths


def run_scan(clamscan_path, target_paths=None, timeout=900):
    if not clamscan_path:
        return None, "ClamAV is not installed", []
    targets = target_paths or default_scan_paths()
    if not targets:
        return None, "No scannable folders found", []
    cmd = [clamscan_path, "-r", "--stdout"] + targets
    try:
        from .ps import SUBPROCESS_FLAGS
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, **SUBPROCESS_FLAGS)
    except subprocess.TimeoutExpired:
        return None, f"Scan timed out after {timeout}s", []
    except (OSError, ValueError) as exc:
        return None, str(exc), []

    infected = [
        {"file": m.group(1).strip(), "signature": m.group(2).strip()}
        for m in INFECTED_RE.finditer(result.stdout)
    ]
    return result.stdout, None, infected


def run():
    info = detect()
    findings = []
    status = {
        "installed": bool(info["clamscan"]),
        "clamscan": info["clamscan"],
        "freshclam": info["freshclam"],
        "db_path": info.get("db_path"),
    }

    if not info["clamscan"]:
        findings.append(finding(
            "malware", "info", "ClamAV is not installed",
            "ClamAV can run as a second, independent malware engine alongside Windows Defender, "
            "useful as a cross-check since no single antivirus catches everything.",
            "Optional: install ClamAV for Windows from clamav.net, then re-run the scan.",
            reference="https://www.clamav.net/download",
        ))
        return findings, {"clamav": status}

    age_days, newest_file, db_files = database_age_days(info["install_dir"])
    status["db_age_days"] = age_days
    status["db_file"] = newest_file
    status["db_files"] = db_files[:10]
    status["db_path"] = info.get("db_path") or _database_dir(info["install_dir"])

    if age_days is None:
        findings.append(finding(
            "malware", "medium", "Could not find a ClamAV signature database",
            "ClamAV is installed but no .cvd/.cld database file was found - it may need its first update.",
            "Click \"Update ClamAV database\" in the dashboard, or run freshclam.exe manually.",
        ))
    elif age_days > 14:
        findings.append(finding(
            "malware", "high", "ClamAV signature database is very outdated",
            f"The newest database file ({newest_file}) is {age_days} days old, so recent malware will likely be missed.",
            "Click \"Update ClamAV database\" in the dashboard.",
        ))
    elif age_days > 3:
        findings.append(finding(
            "malware", "medium", "ClamAV signature database could use an update",
            f"The newest database file ({newest_file}) is {age_days} days old.",
            "Click \"Update ClamAV database\" in the dashboard.",
        ))

    return findings, {"clamav": status}
