"""Advanced network monitoring: active connections with GeoIP-style enrichment,
bandwidth per-process, DNS query log via PowerShell, external IP detection."""
import socket
import psutil
from .risk_engine import finding
from .ps import run_ps_safe

# Known suspicious / C2 ports that external connections should not typically use
SUSPICIOUS_REMOTE_PORTS = {
    4444: "Metasploit default", 1080: "SOCKS proxy", 8080: "Alt-HTTP",
    31337: "Back Orifice", 12345: "NetBus", 6667: "IRC (often used by botnets)",
}

def _process_name(pid):
    if not pid: return "unknown"
    try:
        return psutil.Process(pid).name()
    except (psutil.NoSuchProcess, psutil.AccessDenied):
        return "unknown"

def _process_exe(pid):
    if not pid: return None
    try:
        return psutil.Process(pid).exe()
    except (psutil.NoSuchProcess, psutil.AccessDenied):
        return None

def get_active_connections():
    try:
        conns = psutil.net_connections(kind="inet")
    except (psutil.AccessDenied, PermissionError):
        return [], "Administrator rights required to list all connections."
    results = []
    for c in conns:
        if not c.raddr:
            continue
        remote_ip = c.raddr.ip
        remote_port = c.raddr.port
        is_private = (
            remote_ip.startswith("127.") or remote_ip.startswith("10.") or
            remote_ip.startswith("192.168.") or remote_ip.startswith("172.") or
            remote_ip in ("::1", "")
        )
        try:
            hostname = socket.gethostbyaddr(remote_ip)[0]
        except (socket.herror, socket.gaierror, OSError):
            hostname = ""
        proc = _process_name(c.pid)
        exe = _process_exe(c.pid)
        alert = None
        if not is_private and remote_port in SUSPICIOUS_REMOTE_PORTS:
            alert = f"Suspicious port: {SUSPICIOUS_REMOTE_PORTS[remote_port]}"
        results.append({
            "local_addr": f"{c.laddr.ip}:{c.laddr.port}" if c.laddr else "",
            "remote_ip": remote_ip,
            "remote_port": remote_port,
            "hostname": hostname,
            "status": c.status,
            "pid": c.pid,
            "process": proc,
            "exe": exe,
            "is_external": not is_private,
            "alert": alert,
        })
    return results, None

def get_per_process_net():
    """Returns bytes sent/recv per-process where available."""
    try:
        conns = psutil.net_connections(kind="inet")
    except (psutil.AccessDenied, PermissionError):
        return []
    pids = set(c.pid for c in conns if c.pid)
    results = []
    for pid in pids:
        try:
            p = psutil.Process(pid)
            io = p.io_counters()
            results.append({
                "pid": pid,
                "name": p.name(),
                "read_mb": round(io.read_bytes / (1024**2), 2),
                "write_mb": round(io.write_bytes / (1024**2), 2),
            })
        except (psutil.NoSuchProcess, psutil.AccessDenied, AttributeError):
            continue
    results.sort(key=lambda x: x["read_mb"] + x["write_mb"], reverse=True)
    return results[:20]

def get_firewall_rules():
    data, err = run_ps_safe(
        "Get-NetFirewallRule | Where-Object {$_.Enabled -eq 'True' -and $_.Direction -eq 'Inbound'} | "
        "Select-Object DisplayName,Action,Profile | ConvertTo-Json -Depth 2"
    , timeout=30)
    if err or data is None:
        return [], err
    rules = data if isinstance(data, list) else [data]
    return [{"name": r.get("DisplayName"), "action": str(r.get("Action")), "profile": str(r.get("Profile"))} for r in rules], None

def scan_findings():
    findings = []
    conns, err = get_active_connections()
    suspicious = [c for c in conns if c.get("alert")]
    for c in suspicious:
        findings.append(finding(
            "network", "critical",
            f"Suspicious outbound connection from {c['process']}",
            f"Process {c['process']} (pid {c['pid']}) is connected to {c['remote_ip']}:{c['remote_port']} — {c['alert']}.",
            "Kill the process if unrecognized and run a malware scan immediately.",
            evidence=[c.get("exe") or ""],
        ))
    external = [c for c in conns if c.get("is_external") and not c.get("alert")]
    if len(external) > 20:
        findings.append(finding(
            "network", "medium",
            f"{len(external)} active external connections",
            "A large number of outbound connections may indicate data exfiltration or botnet activity.",
            "Review the Connections table in the Network section for unexpected processes.",
        ))
    return findings
