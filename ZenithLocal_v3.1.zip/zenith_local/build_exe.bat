@echo off
setlocal
title Zenith Local - Build EXE
cd /d "%~dp0"

echo ============================================
echo   Zenith Local - Build Standalone EXE
echo ============================================
echo.
echo This script creates a standalone dist\ZenithLocal.exe
echo that bundles Python so users do NOT need Python installed.
echo.

REM ── Find Python ──────────────────────────────────
set PY_CMD=
where py >nul 2>&1
if not errorlevel 1 (set PY_CMD=py -3) else (
    where python >nul 2>&1
    if not errorlevel 1 (set PY_CMD=python)
)
if "%PY_CMD%"=="" (
    echo [ERROR] Python not found. Install from https://www.python.org/downloads/
    pause & exit /b 1
)

REM ── Ensure venv ──────────────────────────────────
if not exist "venv\Scripts\python.exe" (
    echo Creating virtual environment...
    %PY_CMD% -m venv venv
)
set VENV_PY=venv\Scripts\python.exe

REM ── Install deps + PyInstaller ───────────────────
echo Installing dependencies and PyInstaller...
"%VENV_PY%" -m pip install --quiet --upgrade pip
"%VENV_PY%" -m pip install --quiet -r requirements.txt
"%VENV_PY%" -m pip install --quiet pyinstaller
if errorlevel 1 (
    echo [ERROR] pip install failed.
    pause & exit /b 1
)

REM ── Build ────────────────────────────────────────
echo.
echo Building EXE (this can take 2-5 minutes)...
echo.

"%VENV_PY%" -m PyInstaller ^
    --onefile ^
    --windowed ^
    --name ZenithLocal ^
    --add-data "templates;templates" ^
    --add-data "static;static" ^
    --add-data "scanner;scanner" ^
    --add-data "hskich_config.json;." ^
    --hidden-import=flask ^
    --hidden-import=psutil ^
    --hidden-import=watchdog ^
    --hidden-import=watchdog.observers ^
    --hidden-import=watchdog.events ^
    --hidden-import=werkzeug ^
    --hidden-import=jinja2 ^
    --hidden-import=click ^
    --icon=static\logo.svg ^
    launcher.py

if errorlevel 1 (
    echo.
    echo [ERROR] Build failed. See errors above.
    pause & exit /b 1
)

echo.
echo ============================================
echo   BUILD SUCCESSFUL
echo   File: dist\ZenithLocal.exe
echo.
echo   IMPORTANT: Copy these folders next to the EXE:
echo     templates\
echo     static\
echo     scanner\
echo   (PyInstaller bundles Python itself but the
echo    app files need to be alongside the EXE)
echo ============================================
echo.
pause
