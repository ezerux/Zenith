"""Hashes running processes' executables and, optionally, checks those hashes
against abuse.ch MalwareBazaar - a free, real threat-intel database of confirmed
malware samples. A free Auth-Key (https://auth.abuse.ch/) is required for lookups;
without one, hashing still works but reputation checks are skipped with a clear message."""
import hashlib
import json
import urllib.error
import urllib.parse
import urllib.request

import psutil

from .risk_engine import finding

MB_API_URL = "https://mb-api.abuse.ch/api/v1/"
MB_SIGNUP_URL = "https://auth.abuse.ch/"


def hash_file(path, chunk_size=1024 * 1024):
    try:
        h = hashlib.sha256()
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(chunk_size), b""):
                h.update(chunk)
        return h.hexdigest()
    except (OSError, PermissionError, ValueError):
        return None


def get_process_hashes(limit=40):
    results = []
    seen_paths = set()
    for p in psutil.process_iter(["pid", "name", "exe"]):
        try:
            info = p.info
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue
        path = info.get("exe")
        if not path or path in seen_paths:
            continue
        seen_paths.add(path)
        results.append({
            "pid": info["pid"], "name": info.get("name"), "path": path,
            "sha256": hash_file(path),
        })
        if len(results) >= limit:
            break
    return results


def query_malwarebazaar(sha256, auth_key, timeout=15):
    """Returns (is_known_malware: bool|None, info: dict|None, error: str|None)."""
    if not auth_key:
        return None, None, "no_key"
    body = urllib.parse.urlencode({"query": "get_info", "hash": sha256}).encode()
    req = urllib.request.Request(MB_API_URL, data=body, headers={"Auth-Key": auth_key})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            payload = json.loads(resp.read().decode())
    except (urllib.error.URLError, urllib.error.HTTPError, ValueError, OSError) as exc:
        return None, None, str(exc)

    status = payload.get("query_status")
    if status == "ok" and payload.get("data"):
        entry = payload["data"][0]
        return True, {
            "signature": entry.get("signature"),
            "file_type": entry.get("file_type"),
            "tags": entry.get("tags"),
            "first_seen": entry.get("first_seen"),
        }, None
    if status == "hash_not_found":
        return False, None, None
    return None, None, f"unexpected_response:{status}"


def check_processes(auth_key, limit=15):
    """Hash the top `limit` running processes' executables and, if a key is
    configured, check each hash against MalwareBazaar. Findings are only produced
    for confirmed hits - never for lookup errors or missing keys."""
    processes = get_process_hashes(limit=limit)
    findings = []
    results = []
    for proc in processes:
        entry = dict(proc)
        if proc["sha256"] and auth_key:
            is_bad, info, err = query_malwarebazaar(proc["sha256"], auth_key)
            entry["malwarebazaar"] = {"known_malware": is_bad, "info": info, "error": err}
            if is_bad:
                sig = f' (signature: {info.get("signature")})' if info and info.get("signature") else ""
                findings.append(finding(
                    "malware", "critical",
                    f'Known malware hash detected: {proc["name"]} (PID {proc["pid"]})',
                    f'SHA256 {proc["sha256"]} matches a confirmed-malicious sample on MalwareBazaar{sig}.',
                    "Isolate this immediately: end the process, quarantine or delete the file, and run a full antivirus scan.",
                    reference="https://bazaar.abuse.ch/browse.php",
                    evidence=[proc["path"]],
                ))
        else:
            entry["malwarebazaar"] = {"known_malware": None, "info": None, "error": "no_key" if not auth_key else "no_hash"}
        results.append(entry)
    return findings, results
