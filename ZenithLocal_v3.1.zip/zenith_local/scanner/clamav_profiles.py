"""ClamAV scan profiles - Quick, Standard, Full.
Quick: high-risk locations only (Temp, Downloads, Desktop, Startup).
Standard: user home + system paths commonly abused by malware.
Full: entire drives (slow, long timeout).
Also provides the local signature database stats."""
import glob
import os
from .clamav_scan import detect, run_scan, INFECTED_RE

PROFILES = {
    "quick": {
        "label": "Quick Scan",
        "description": "High-risk folders only: Downloads, Desktop, Temp, Startup (~2-5 min)",
        "timeout": 300,
    },
    "standard": {
        "label": "Standard Scan",
        "description": "User home folder + AppData + ProgramData (~10-20 min)",
        "timeout": 1200,
    },
    "full": {
        "label": "Full Scan",
        "description": "All local drives — thorough but slow (~30-90 min)",
        "timeout": 7200,
    },
}

def get_profile_paths(profile, extra_paths=None):
    home    = os.environ.get("USERPROFILE") or os.path.expanduser("~")
    appdata = os.environ.get("APPDATA") or os.path.join(home, "AppData", "Roaming")
    localad = os.environ.get("LOCALAPPDATA") or os.path.join(home, "AppData", "Local")
    temp    = os.environ.get("TEMP") or os.path.join(localad, "Temp")
    progd   = os.environ.get("PROGRAMDATA") or r"C:\ProgramData"
    startup = os.path.join(appdata, "Microsoft", "Windows", "Start Menu", "Programs", "Startup")

    if profile == "quick":
        candidates = [
            os.path.join(home, "Downloads"),
            os.path.join(home, "Desktop"),
            temp, startup,
        ]
    elif profile == "standard":
        candidates = [home, progd]
    else:  # full
        # all fixed local drives
        candidates = []
        import string
        for letter in string.ascii_uppercase:
            drive = f"{letter}:\\"
            if os.path.isdir(drive):
                candidates.append(drive)
    valid = [p for p in candidates if p and os.path.isdir(p)]
    if extra_paths:
        valid += [p for p in extra_paths if p and os.path.isdir(p)]
    return valid

def run_profile_scan(profile="quick", extra_paths=None, clamscan_path=None):
    """Run a profile scan. Returns (output, error, infected_list, scanned_paths)."""
    info = detect()
    cs   = clamscan_path or info["clamscan"]
    if not cs:
        return None, "ClamAV not installed", [], []
    cfg    = PROFILES.get(profile, PROFILES["quick"])
    paths  = get_profile_paths(profile, extra_paths)
    out, err, infected = run_scan(cs, paths, timeout=cfg["timeout"])
    return out, err, infected, paths

def get_db_stats():
    """Return stats about the local ClamAV signature database."""
    info = detect()
    if not info["clamscan"]:
        return {"installed": False}
    install_dir = info["install_dir"]
    if not install_dir:
        return {"installed": True, "db_files": []}
    cvd_files = []
    for root, _, files in os.walk(install_dir):
        for fname in files:
            if fname.endswith(".cvd") or fname.endswith(".cld"):
                full = os.path.join(root, fname)
                try:
                    size_mb = round(os.path.getsize(full) / (1024 * 1024), 1)
                    import datetime
                    mtime = datetime.datetime.fromtimestamp(os.path.getmtime(full))
                    cvd_files.append({
                        "name": fname,
                        "path": full,
                        "size_mb": size_mb,
                        "modified": str(mtime.date()),
                        "age_days": (datetime.datetime.now() - mtime).days,
                    })
                except OSError:
                    pass
    cvd_files.sort(key=lambda x: x["age_days"])
    return {"installed": True, "db_files": cvd_files, "db_dir": install_dir}
