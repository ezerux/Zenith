"""Windows Firewall Manager — list, enable/disable rules, add/delete rules."""
from .ps import run_ps_safe, run_ps

DIRECTION_MAP = {"Inbound": "In", "Outbound": "Out", "In": "In", "Out": "Out"}

def list_rules(direction="all", action_filter="all", filter_text="", enabled_only=False):
    where_parts = []
    if direction != "all":
        d = DIRECTION_MAP.get(direction, direction)
        where_parts.append(f"$_.Direction -eq '{d}'")
    if action_filter != "all":
        where_parts.append(f"$_.Action -eq '{action_filter}'")
    if enabled_only:
        where_parts.append("$_.Enabled -eq 'True'")

    where_clause = ""
    if where_parts:
        where_clause = "| Where-Object {" + " -and ".join(where_parts) + "}"

    cmd = (
        f"Get-NetFirewallRule {where_clause} "
        "| Select-Object Name,DisplayName,Direction,Action,Enabled,Profile,Description "
        "| ConvertTo-Json -Depth 2"
    )
    data, err = run_ps_safe(cmd, timeout=40)
    if err or not data:
        return [], err or "Could not list firewall rules (Administrator required)."

    rules = data if isinstance(data, list) else [data]
    if filter_text:
        ft = filter_text.lower()
        rules = [r for r in rules if
                 ft in (r.get("DisplayName") or "").lower() or
                 ft in (r.get("Name") or "").lower()]

    return [{
        "name":        r.get("Name", ""),
        "display":     r.get("DisplayName", ""),
        "direction":   str(r.get("Direction", "")),
        "action":      str(r.get("Action", "")),
        "enabled":     str(r.get("Enabled", "")).lower() == "true",
        "profile":     str(r.get("Profile", "")),
        "description": r.get("Description", ""),
    } for r in rules], None


def set_rule_enabled(name, enabled: bool):
    """Enable or disable a firewall rule by name."""
    safe  = name.replace('"','').replace("'","").replace(";","").strip()
    state = "True" if enabled else "False"
    try:
        run_ps(f"Set-NetFirewallRule -Name '{safe}' -Enabled {state} -ErrorAction Stop", timeout=20)
        return True, None
    except Exception as exc:
        return False, str(exc)


def add_rule(display_name, direction, action, protocol, local_port=None, remote_address=None, description=""):
    """Add a new inbound/outbound firewall rule."""
    safe_name = display_name.replace('"','').replace("'","").replace(";","").strip()[:64]
    dir_val   = DIRECTION_MAP.get(direction, "In")

    params = [
        f"-DisplayName '{safe_name}'",
        f"-Direction {dir_val}",
        f"-Action {action}",
        f"-Protocol {protocol}",
        f"-Enabled True",
        f"-Profile Any",
    ]
    if local_port:
        params.append(f"-LocalPort {int(local_port)}")
    if remote_address:
        safe_addr = remote_address.replace("'","").replace(";","").strip()
        params.append(f"-RemoteAddress '{safe_addr}'")
    if description:
        safe_desc = description.replace("'","").replace(";","").strip()[:120]
        params.append(f"-Description '{safe_desc}'")

    cmd = "New-NetFirewallRule " + " ".join(params) + " -ErrorAction Stop"
    try:
        run_ps(cmd, timeout=20)
        return True, None
    except Exception as exc:
        return False, str(exc)


def delete_rule(name):
    """Delete a firewall rule by name."""
    safe = name.replace('"','').replace("'","").replace(";","").strip()
    try:
        run_ps(f"Remove-NetFirewallRule -Name '{safe}' -ErrorAction Stop", timeout=20)
        return True, None
    except Exception as exc:
        return False, str(exc)


def get_profile_status():
    """Return enabled/disabled status for Domain, Private, Public profiles."""
    data, err = run_ps_safe(
        "Get-NetFirewallProfile | Select-Object Name,Enabled | ConvertTo-Json", timeout=15)
    if err or not data:
        return {}, err
    profiles = data if isinstance(data, list) else [data]
    return {p["Name"]: p["Enabled"] for p in profiles if "Name" in p}, None


def set_profile_enabled(profile_name, enabled: bool):
    """Enable or disable an entire firewall profile (Domain/Private/Public)."""
    state = "True" if enabled else "False"
    try:
        run_ps(f"Set-NetFirewallProfile -Name {profile_name} -Enabled {state} -ErrorAction Stop", timeout=15)
        return True, None
    except Exception as exc:
        return False, str(exc)
