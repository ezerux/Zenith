"""Folder scanner: recursively walk a path and report suspicious files
(unusual extensions, double-extension, scripts, tiny/huge executables, etc.)
then pipe findings through ClamAV if available."""
import os
import hashlib
import stat
from .risk_engine import finding

DOUBLE_EXT = [".pdf.exe", ".docx.exe", ".jpg.exe", ".txt.exe", ".xlsx.exe", ".png.exe"]
SCRIPT_EXT = {".ps1", ".vbs", ".js", ".bat", ".cmd", ".hta", ".wsf", ".wsh"}
EXEC_EXT   = {".exe", ".dll", ".scr", ".com", ".pif"}

def sha256_of(path):
    try:
        h = hashlib.sha256()
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(65536), b""):
                h.update(chunk)
        return h.hexdigest()
    except OSError:
        return None

def scan_folder(folder, max_files=2000):
    """Walk folder and return (findings, file_list)."""
    results  = []
    findings = []
    count    = 0

    if not os.path.isdir(folder):
        return [finding("malware","medium","Folder not found",
            f"The requested path does not exist or is not accessible: {folder}",
            "Check the path and try again.")], []

    for root, dirs, files in os.walk(folder):
        dirs[:] = [d for d in dirs if not d.startswith(".")]
        for fname in files:
            if count >= max_files:
                break
            count += 1
            fpath = os.path.join(root, fname)
            try:
                size  = os.path.getsize(fpath)
                mtime = os.path.getmtime(fpath)
            except OSError:
                continue

            lower = fname.lower()
            ext   = os.path.splitext(lower)[1]
            flags = []

            # Double extension
            for de in DOUBLE_EXT:
                if lower.endswith(de):
                    flags.append(f"double extension ({de})")

            # Script files
            if ext in SCRIPT_EXT:
                flags.append(f"script file ({ext})")

            # Exe/DLL in Downloads/Temp
            if ext in EXEC_EXT and any(seg in root.lower() for seg in ("temp","downloads","tmp")):
                flags.append(f"executable in high-risk folder ({ext})")

            # Very large executable (>150 MB) — sometimes packed malware
            if ext in EXEC_EXT and size > 150 * 1024 * 1024:
                flags.append("unusually large executable")

            # Zero-byte executable
            if ext in EXEC_EXT and size == 0:
                flags.append("zero-byte executable")

            sev = "high" if any("double extension" in f or "script" in f for f in flags) else "medium" if flags else None
            fhash = sha256_of(fpath) if flags and ext in EXEC_EXT else None
            entry = {
                "path": fpath, "name": fname, "size": size,
                "mtime": mtime, "flags": flags, "sha256": fhash,
            }
            results.append(entry)
            if flags:
                findings.append(finding(
                    "malware", sev or "low",
                    f"Suspicious file: {fname}",
                    f"Path: {fpath} — {'; '.join(flags)}. Size: {round(size/1024,1)} KB.",
                    "Investigate the file. If unknown, quarantine it and run ClamAV on it.",
                    evidence=[fpath],
                ))

    return findings, results
